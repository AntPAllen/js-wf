import pathlib,json,hashlib,subprocess,re
root=pathlib.Path(__file__).parent;repo=pathlib.Path('/home/exedev/js-wf');race=pathlib.Path('/tmp/js-wf-current-race-37172701931');run=json.loads((root/'run.json').read_text());job=json.loads((root/'job.json').read_text());source='f149b873b349f6def63b50a29d79abb1c142739f';accepted='283ba325c31fe67194f0a0d7e11665b0bea405ed'
assert run['id']==37177259306 and run['head_sha']==source and run['status']=='completed' and run['conclusion']=='failure'
assert job['id']==111362365148 and job['run_id']==run['id'] and job['head_sha']==source and job['status']=='completed' and job['conclusion']=='failure'
artifacts=[a for page in json.loads((root/'artifacts.json').read_text()) for a in page['artifacts']];artifact=next(a for a in artifacts if a['id']==11293764137);assert artifact['name']=='lease-consumer-pressure' and artifact['workflow_run']['head_sha']==source
(root/'artifact.json').write_text(json.dumps(artifact,indent=2)+'\n')
rows=json.loads((root/'raw/lease-consumer-pressure.json').read_text());assert len(rows)==4
for row in rows[:3]:assert not row['delayed'] and all(x['calls']==48 and not x.get('error') for x in row['owners'])
row=rows[-1];assert row['delayed'] and not row.get('consumer_traffic') and not row.get('contenders') and len(row['owners'])==8
failed=[o for o in row['owners'] if o.get('error')];assert len(failed)==1;owner=failed[0];assert owner['id']=='dtrue-atrue-w8-2' and owner['calls']==6 and 'tail lookup' in owner['error'] and 'code=503 err_code=10008' in owner['error'];assert all(x['calls']==48 for x in row['owners'] if not x.get('error'))
log=(root/'job.log').read_text();match=re.search(r'--- FAIL: TestLeaseAppendPressureConsumerTrafficFixedPlacement \(([^)]+)\)',log);assert match and 'FAIL\tjs-wf/integration\t26.992s' in log
placement={}
for node in [0,1]:
 j=json.loads((root/f'raw/lease-consumer-pressure-server-{node}-jetstream-final.json').read_text());streams={s['name']:s for a in j['account_details'] for s in a.get('stream_detail',[])}
 placement[str(node)]={}
 for name,leader in [('WF_JRN','wf-process-1'),('KV_WF_LEASE','wf-process-0'),('KV_WF_STATE','wf-process-0')]:
  s=streams[name];assert s['cluster']['leader']==leader;peer=next(p for p in s['cluster']['replicas'] if p['name']==f'wf-process-{1-node}');assert peer['current'];placement[str(node)][name]=dict(leader=leader,surviving_peer_current=True,messages=s['state']['messages'])
stopped=json.loads((root/'raw/lease-consumer-pressure-server-2-jetstream-final.json').read_text());assert 'connection refused' in stopped['diagnostic_error']
race_review=json.loads((race/'independent-review.json').read_text());assert race_review['accepted'] and race_review['race_instrumented'] and race_review['source']==accepted
suite=json.loads((race/'artifact/tier1-result.json').read_text());assert suite==race_review['suite'];proof=suite['per_workload_seed_proof'];test='TestSeededWorkerTailLookupRecovery';assert test in proof['tests'] and proof['first']==1 and proof['last']==1000 and proof['workloads']==121
ledger=json.loads((race/'runtime-equivalence.json').read_text())['files'];assert len(ledger)==685
for n,d in ledger.items():
 for rev in [accepted,source]:assert hashlib.sha256(subprocess.check_output(['git','show',rev+':'+n],cwd=repo)).hexdigest()==d,(rev,n)
(root/'runtime-equivalence.json').write_text(json.dumps(dict(accepted_race_source=accepted,failed_ci_source=source,all_685_selected_bytes_match=True,files=ledger,scope='Non-test runtime Go/modules, full simulator corpus/pins and Tier1 producer/guard/race workflow; excludes integration fixtures.'),indent=2)+'\n')
events=[]
for line in (race/'artifact/tier1-events.jsonl').read_text().splitlines():
 e=json.loads(line)
 if e.get('Test')==test:events.append(e)
assert sum(e['Action']=='pass' for e in events)==1
outputs=''.join(e.get('Output','') for e in events);assert f'TIER1_SEEDS test={test} first=1 last=1000 completed=1000 requested=1000' in outputs
m=re.search(r'recovery stages/counts=map\[([^]]+)\]',outputs);assert m
counts={k:int(v) for k,v in (item.split(':') for item in m[1].split())};assert len(counts)==12 and sum(counts.values())==1000 and all(v>0 for v in counts.values())
(root/'accepted-race-workload-events.jsonl').write_text(''.join(json.dumps(e,separators=(',',':'))+'\n' for e in events));(root/'accepted-race-suite.json').write_text(json.dumps(suite,indent=2)+'\n')
manifest=json.loads((repo/'docs/scale/snapshot-timeout-cause-2026-10-04/hosted-race/manifest.json').read_text())
# Bind selected events and suite to the existing complete accepted evidence and actual binary.
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['artifact/sim.test','artifact/tier1-result.json','artifact/tier1-events.jsonl','independent-review.json','runtime-equivalence.json']:
 assert sha(race/n)==manifest['files'][n]['sha256'],n
assert sha(race/'artifact/sim.test')==race_review['retained_binary_sha256']
(root/'executed-source').mkdir(exist_ok=True)
source_files={}
for n in ['integration/lease_append_pressure_test.go','journal/journal.go','worker/worker.go','sim/worker_tail_lookup_replay_test.go','.github/workflows/tier2-mixed.yml']:
 data=subprocess.check_output(['git','show',source+':'+n],cwd=repo);p=root/'executed-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);source_files[n]=hashlib.sha256(data).hexdigest()
analysis=dict(run=run['id'],job=job['id'],source=source,artifact=artifact['id'],artifact_zip_bytes=artifact['size_in_bytes'],named_test_seconds=match[1],package_seconds=26.992,report_rows=4,successful_rows=3,failed_row_delayed=True,failed_row_consumer_traffic=False,failed_row_contenders=False,failed_owner=owner,other_seven_owners_calls=48,later_monitoring=placement,stopped_node=stopped,server_cause_confirmed=False,physical_stores_retained=False,failed_workload_executable_retained=False,producer_source_capture_available=False,selected_git_source_sha256=source_files,accepted_race_run=37172701931,accepted_race_job=111348770188,accepted_race_source=accepted,accepted_race_binary_sha256=race_review['retained_binary_sha256'],accepted_race_proof='docs/scale/snapshot-timeout-cause-2026-10-04/hosted-race/',accepted_workload=test,accepted_workload_contiguous_seeds=1000,accepted_stage_count_coverage=counts,runtime_simulator_selected_inputs_match=685,qualification_promoted=False,new_test_or_campaign_started=False,scope='Rejected steady-pressure measurement. The harness exits on ErrUnknown; existing source-identical simulation exercises actual Worker redelivery, preserved prefixes, released leases and final retained integrity after injected API errors. This does not reproduce the server cause or qualify this failed pressure comparison.')
(root/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n');print(json.dumps({k:v for k,v in analysis.items() if k not in ['later_monitoring','selected_git_source_sha256','accepted_stage_count_coverage','stopped_node']},indent=2))
