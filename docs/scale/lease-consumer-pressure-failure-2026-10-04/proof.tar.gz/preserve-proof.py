import pathlib,json,hashlib,tarfile
root=pathlib.Path(__file__).parent;out=pathlib.Path('/home/exedev/js-wf/docs/scale/lease-consumer-pressure-failure-2026-10-04');out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file() and p.name!='proof.tar.gz'}
ledger={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()}
archive=root/'proof.tar.gz.tmp'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  assert m.isfile() and m.name not in seen;seen.add(m.name);data=t.extractfile(m).read();assert len(data)==ledger[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==ledger[m.name]['sha256'],m.name
assert seen==set(ledger)
for n,p in files.items():assert sha(p)==ledger[n]['sha256'],n
archive.rename(root/'proof.tar.gz');p=root/'proof.tar.gz';dest=out/'proof.tar.gz';dest.write_bytes(p.read_bytes());assert sha(dest)==sha(p)
(out/'manifest.json').write_text(json.dumps(dict(files=ledger,archive_sha256=sha(p),archive_bytes=p.stat().st_size,all_members_readback_sha_verified=True,failed_job_preserved=True,qualification_promoted=False),indent=2)+'\n');(out/'analysis.json').write_bytes((root/'analysis.json').read_bytes());print(len(ledger),p.stat().st_size)
