import pathlib,json,hashlib,tarfile
repo=pathlib.Path('/home/exedev/js-wf');root=pathlib.Path(__file__).parent;out=repo/'docs/scale/partition-start-fault-duration-2026-10-04';out.mkdir(exist_ok=True)
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file() and p.name not in {'fixture-proof.tar.gz','fixture-proof.tar.gz.tmp'}}
ledger={n:dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for n,p in files.items()};archive=root/'fixture-proof.tar.gz.tmp'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  assert m.isfile() and m.name not in seen;seen.add(m.name);data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==ledger[m.name]['sha256'] and len(data)==ledger[m.name]['bytes']
assert seen==set(ledger)
for n,p in files.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==ledger[n]['sha256'],n
archive.rename(root/'fixture-proof.tar.gz');data=(root/'fixture-proof.tar.gz').read_bytes();(out/'fixture-proof.tar.gz').write_bytes(data);assert (out/'fixture-proof.tar.gz').read_bytes()==data
(out/'manifest.json').write_text(json.dumps(dict(files=ledger,archive_sha256=hashlib.sha256(data).hexdigest(),archive_bytes=len(data),all_members_readback_sha_verified=True,actual_focused_test_executables_retained=False,full_100000_count_proof_completed=False),indent=2)+'\n');print(len(ledger),len(data))
