package server

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"sync/atomic"
	"testing"
	"time"
)

// This diagnostic opens only copies supplied by the external runner. Recovery
// mode keeps scheduling paused: there is no server, Raft, callback or publication.
// Reopen probes record the observed counts explicitly; earlier full snapshots
// including deleted-sequence lists remain preserved in their original trials.
func workflowCopiedStateArtifact(s StreamState) any {
	if os.Getenv("WF_COPIED_STORE_REOPEN") != "1" {
		return s
	}
	return struct {
		Format   string `json:"format"`
		Messages uint64 `json:"messages"`
		FirstSeq uint64 `json:"first_seq"`
		LastSeq  uint64 `json:"last_seq"`
	}{"counts-v1", s.Msgs, s.FirstSeq, s.LastSeq}
}

func TestWorkflowCopiedSchedulingIndexBoundary(t *testing.T) {
	root := os.Getenv("WF_COPIED_STORE_BOUNDARY_ROOT")
	if root == "" {
		t.Fatal("copied-store root required")
	}
	for _, mode := range []string{"removed", "intact"} {
		for node, expected := range []uint64{768, 141, 0} {
			t.Run(fmt.Sprintf("%s/node-%d", mode, node), func(t *testing.T) {
				dir := filepath.Join(root, "copies", mode, fmt.Sprintf("node-%d", node))
				raw, err := os.ReadFile(filepath.Join(dir, "meta.inf"))
				if err != nil {
					t.Fatal(err)
				}
				var meta struct {
					StreamConfig
					Created time.Time
				}
				if err := json.Unmarshal(raw, &meta); err != nil {
					t.Fatal(err)
				}
				if meta.Name != "WF_RUN" || !meta.AllowMsgSchedules || meta.Storage != FileStorage {
					t.Fatal("wrong source store")
				}
				fs, err := newFileStoreWithCreatedAndMode(FileStoreConfig{StoreDir: dir}, meta.StreamConfig, meta.Created, nil, nil, true)
				if err != nil {
					t.Fatal(err)
				}
				defer func() {
					if err := fs.Stop(); err != nil {
						t.Error(err)
					}
				}()
				state := fs.State()
				fs.mu.Lock()
				count := len(fs.scheduling.schedules)
				paused := fs.scheduling.paused
				schedules := make(map[string]uint64, count)
				for subject, schedule := range fs.scheduling.schedules {
					schedules[subject] = schedule.seq
				}
				fs.mu.Unlock()
				report := struct {
					Mode      string            `json:"mode"`
					Node      int               `json:"node"`
					State     any               `json:"state"`
					Paused    bool              `json:"paused"`
					Schedules map[string]uint64 `json:"schedules"`
				}{mode, node, workflowCopiedStateArtifact(state), paused, schedules}
				data, err := json.MarshalIndent(report, "", "  ")
				if err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("%s-node-%d.json", mode, node)), data, 0644); err != nil {
					t.Fatal(err)
				}
				if state.Msgs != expected || state.LastSeq != 2000000 {
					t.Fatalf("physical messages=%d last=%d, want %d/2000000", state.Msgs, state.LastSeq, expected)
				}
				if !paused {
					t.Fatal("recovery scheduling must stay paused")
				}
				want := 0
				if mode == "removed" {
					want = int(expected)
				}
				if count != want {
					t.Fatalf("recovered schedules=%d want=%d", count, want)
				}
				for subject, seq := range schedules {
					msg, err := fs.LoadMsg(seq, nil)
					if err != nil || msg.subj != subject || string(getHeader(JSScheduleTarget, msg.hdr)) == "" {
						t.Fatalf("recovered source %s/%d invalid: %v", subject, seq, err)
					}
				}
				if os.Getenv("WF_COPIED_STORE_SUBJECT_PURGE") == "1" {
					// The removed-index case discovers all physical source names.
					// Reuse that read-only report to probe the intact-index copy.
					known := schedules
					if mode == "intact" {
						raw, err := os.ReadFile(filepath.Join(root, fmt.Sprintf("removed-node-%d.json", node)))
						if err != nil {
							t.Fatal(err)
						}
						var found struct {
							Schedules map[string]uint64 `json:"schedules"`
						}
						if err := json.Unmarshal(raw, &found); err != nil {
							t.Fatal(err)
						}
						known = found.Schedules
					}
					subjects := make([]string, 0, len(known))
					for subject := range known {
						subjects = append(subjects, subject)
					}
					sort.Strings(subjects)
					type probe struct {
						Subject        string `json:"subject"`
						Sequence       uint64 `json:"sequence"`
						LookupSequence uint64 `json:"lookup_sequence"`
						Purged         uint64 `json:"purged"`
						AbsentAfter    bool   `json:"absent_after"`
						DirectError    string `json:"direct_error"`
						SubjectError   string `json:"subject_error"`
					}
					probes := make([]probe, 0, len(subjects))
					// Save every completed probe even if a later assertion fails.
					defer func() {
						data, err := json.MarshalIndent(struct {
							Mode   string  `json:"mode"`
							Node   int     `json:"node"`
							Before any     `json:"before"`
							After  any     `json:"after"`
							Probes []probe `json:"probes"`
						}{mode, node, workflowCopiedStateArtifact(state), workflowCopiedStateArtifact(fs.State()), probes}, "", "  ")
						if err != nil {
							t.Error(err)
							return
						}
						if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("subject-purge-%s-node-%d.json", mode, node)), data, 0644); err != nil {
							t.Error(err)
						}
					}()
					if uint64(len(subjects)) != expected {
						t.Fatalf("source inventory=%d want=%d", len(subjects), expected)
					}
					for _, subject := range subjects {
						seq := known[subject]
						msg, err := fs.LoadLastMsg(subject, nil)
						if err != nil || msg.seq != seq || msg.subj != subject {
							t.Fatalf("subject lookup %s/%d: msg=%v err=%v", subject, seq, msg, err)
						}
						removed, err := fs.PurgeEx(subject, 0, 0)
						if err != nil || removed != 1 {
							t.Fatalf("subject purge %s/%d: removed=%d err=%v", subject, seq, removed, err)
						}
						_, directErr := fs.LoadMsg(seq, nil)
						_, subjectErr := fs.LoadLastMsg(subject, nil)
						absent := (errors.Is(directErr, ErrStoreMsgNotFound) || errors.Is(directErr, errDeletedMsg) || errors.Is(directErr, ErrStoreEOF)) && errors.Is(subjectErr, ErrStoreMsgNotFound)
						probes = append(probes, probe{subject, seq, msg.seq, removed, absent, fmt.Sprint(directErr), fmt.Sprint(subjectErr)})
						if !absent {
							t.Fatalf("source remains after purge %s/%d: direct=%v subject=%v", subject, seq, directErr, subjectErr)
						}
					}
					after := fs.State()
					if after.Msgs != 0 || after.LastSeq != state.LastSeq {
						t.Fatalf("purged store messages=%d last=%d", after.Msgs, after.LastSeq)
					}
					if os.Getenv("WF_COPIED_STORE_REOPEN") == "1" {
						if err := fs.Stop(); err != nil {
							t.Fatal(err)
						}
						reopened, err := newFileStoreWithCreatedAndMode(FileStoreConfig{StoreDir: dir}, meta.StreamConfig, meta.Created, nil, nil, true)
						if err != nil {
							t.Fatal(err)
						}
						fs = reopened
						recovered := fs.State()
						checks := 0
						for _, subject := range subjects {
							_, directErr := fs.LoadMsg(known[subject], nil)
							_, subjectErr := fs.LoadLastMsg(subject, nil)
							if !(errors.Is(directErr, ErrStoreMsgNotFound) || errors.Is(directErr, errDeletedMsg) || errors.Is(directErr, ErrStoreEOF)) || !errors.Is(subjectErr, ErrStoreMsgNotFound) {
								t.Fatalf("source returned after reopen %s: direct=%v subject=%v", subject, directErr, subjectErr)
							}
							checks++
						}
						fs.mu.Lock()
						recoveredSchedules := len(fs.scheduling.schedules)
						isPaused := fs.scheduling.paused
						fs.mu.Unlock()
						raw, err := json.MarshalIndent(struct {
							Mode          string `json:"mode"`
							Node          int    `json:"node"`
							State         any    `json:"state"`
							Schedules     int    `json:"schedules"`
							Paused        bool   `json:"paused"`
							AbsentSources int    `json:"absent_sources"`
							CleanStop     bool   `json:"clean_stop"`
						}{mode, node, workflowCopiedStateArtifact(recovered), recoveredSchedules, isPaused, checks, true}, "", "  ")
						if err != nil {
							t.Fatal(err)
						}
						if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("reopened-%s-node-%d.json", mode, node)), raw, 0644); err != nil {
							t.Fatal(err)
						}
						if recovered.Msgs != 0 || recovered.LastSeq != 2000000 || !isPaused {
							t.Fatalf("reopen messages=%d last=%d schedules=%d paused=%t", recovered.Msgs, recovered.LastSeq, recoveredSchedules, isPaused)
						}
						if os.Getenv("WF_COPIED_STORE_RESUME") != "1" {
							if recoveredSchedules != 0 {
								t.Fatalf("reopen messages=%d last=%d schedules=%d paused=%t", recovered.Msgs, recovered.LastSeq, recoveredSchedules, isPaused)
							}
						} else {
							// Keep the before-resume report even if actual cleanup fails.
							var callbacks atomic.Int64
							fs.RegisterProcessJetStreamMsg(func(*inMsg) { callbacks.Add(1) })
							fs.mu.Lock()
							for _, sched := range fs.scheduling.schedules {
								if sched.ts > time.Now().UnixNano() {
									fs.mu.Unlock()
									t.Fatal("future schedule cannot test expiry cleanup")
								}
							}
							// Invoke the production loop directly, without a timer race.
							fs.scheduling.paused = false
							fs.mu.Unlock()
							fs.runMsgScheduling()
							fs.mu.Lock()
							remaining := len(fs.scheduling.schedules)
							fs.mu.Unlock()
							if err := fs.Stop(); err != nil {
								t.Fatal(err)
							}
							reopened, err := newFileStoreWithCreatedAndMode(FileStoreConfig{StoreDir: dir}, meta.StreamConfig, meta.Created, nil, nil, true)
							if err != nil {
								t.Fatal(err)
							}
							fs = reopened
							fs.mu.Lock()
							persisted := len(fs.scheduling.schedules)
							fs.mu.Unlock()
							raw, err := json.MarshalIndent(struct {
								Before    int   `json:"schedules_before_resume"`
								After     int   `json:"schedules_after_resume"`
								Reopened  int   `json:"schedules_after_second_reopen"`
								Callbacks int64 `json:"target_callbacks"`
								State     any   `json:"state"`
							}{recoveredSchedules, remaining, persisted, callbacks.Load(), workflowCopiedStateArtifact(fs.State())}, "", "  ")
							if err != nil {
								t.Fatal(err)
							}
							if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("resumed-%s-node-%d.json", mode, node)), raw, 0644); err != nil {
								t.Fatal(err)
							}
							if remaining != 0 || persisted != 0 || callbacks.Load() != 0 || fs.State().Msgs != 0 || fs.State().LastSeq != 2000000 {
								t.Fatalf("resume cleanup remaining=%d persisted=%d callbacks=%d state=%+v", remaining, persisted, callbacks.Load(), fs.State())
							}
						}
					}
				}
			})
		}
	}
}
