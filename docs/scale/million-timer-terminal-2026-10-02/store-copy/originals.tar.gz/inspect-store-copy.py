from pathlib import Path
import socket,subprocess,shutil,time,json,urllib.request,hashlib
original=Path('/tmp/js-wf-timer-volume-million-service-20261001/cluster')
out=Path('/tmp/js-wf-million-store-copy-20261002');out.mkdir()
manifest=[]
for p in sorted(original.rglob('*')):
 if p.is_file():manifest.append({'path':str(p.relative_to(original)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'original-store-before.json').write_text(json.dumps(manifest,indent=2)+'\n')
for i in range(3):shutil.copytree(original/f'node-{i}',out/f'node-{i}')
held=[];ports=[]
for i in range(9):
 s=socket.socket();s.bind(('127.0.0.1',0));held.append(s);ports.append(s.getsockname()[1])
for s in held:s.close()
procs=[];files=[]
try:
 for i in range(3):
  args=[str(original/'nats-server'),'-a','127.0.0.1','-p',str(ports[i]),'-m',str(ports[3+i]),'-n',f'wf-process-{i}','-js','-sd',str(out/f'node-{i}'),'--cluster',f'nats://127.0.0.1:{ports[6+i]}','--cluster_name','wf-process','--routes',','.join(f'nats://127.0.0.1:{ports[6+j]}' for j in range(3) if j!=i)]
  f=(out/f'node-{i}.log').open('w');files.append(f);procs.append(subprocess.Popen(args,stdout=f,stderr=f))
 (out/'processes.json').write_text(json.dumps({'ports':ports,'pids':[p.pid for p in procs]},indent=2)+'\n')
 for tick in range(5):
  time.sleep(4)
  for i in range(3):
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{ports[3+i]}/jsz?streams=true&consumers=true&config=true',timeout=2) as r:data=r.read()
    (out/f'snapshot-{tick}-node-{i}.json').write_bytes(data)
   except Exception as e:(out/f'snapshot-{tick}-node-{i}.error').write_text(str(e))
finally:
 for p in procs:p.terminate()
 for p in procs:
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 for f in files:f.close()
 after=[{'path':str(p.relative_to(original)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(original.rglob('*')) if p.is_file()]
 assert after==manifest,'original stores changed'
 (out/'original-stores-unchanged.json').write_text(json.dumps({'all_original_file_hashes_unchanged':True,'files':len(manifest)},indent=2)+'\n')
print(out)
