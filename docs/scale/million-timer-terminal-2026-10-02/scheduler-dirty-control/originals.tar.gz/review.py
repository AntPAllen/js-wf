#!/usr/bin/env python3
"""Review the isolated NATS scheduling cleanup control from raw evidence."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

root = Path(sys.argv[1]).resolve()
original = Path('/tmp/js-wf-timer-volume-million-service-20261001')
repo = Path('/home/exedev/js-wf')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):
    return json.loads((root/name).read_text())
def inventory(p):
    return {str(f.relative_to(p)): sha(f) for f in sorted(p.rglob('*')) if f.is_file()}

before = read('original-before.json')
assert len(before) == 4998
assert before == read('original-after.json') == inventory(original)
source = read('source.json')
assert source['version'] == 'v2.15.0'
assert source['head'] == 'e824cc1f90a847725c2028f8bc890e1ae4dbf1a9'
module = Path(source['module'])
upstream = read('module-inventory.json')
assert upstream == inventory(module)
assert source['module_files'] == {n: sha(module/n) for n in source['module_files']}
baseline = (root/'baseline-filestore.go.txt').read_bytes()
assert baseline == (module/'server/filestore.go').read_bytes()
text = baseline.decode()
anchor = '\tfs.scheduling.running = true\n\n\tscheduledMsgs := fs.scheduling.getScheduledMessages('
assert text.count(anchor) == 1
expected = text.replace(anchor, '\tfs.scheduling.running = true\n\tpriorScheduleCount := len(fs.scheduling.schedules)\n\n\tscheduledMsgs := fs.scheduling.getScheduledMessages(')
pos = expected.index('\n\tif len(scheduledMsgs) > 0 {', expected.index('func (fs *fileStore) runMsgScheduling()'))
expected = expected[:pos] + '\n\tif len(fs.scheduling.schedules) != priorScheduleCount {\n\t\tfs.dirty++\n\t}\n' + expected[pos:]
assert (root/'dirty-count-control.go.txt').read_bytes() == expected.encode()
change = read('compiled-source-change.json')
assert change['baseline_sha256'] == hashlib.sha256(baseline).hexdigest()
assert change['modified_sha256'] == hashlib.sha256(expected.encode()).hexdigest()
assert change['path'] == 'server/filestore.go'
compiled = inventory(root/'nats-source')
assert compiled.pop('server/workflow_copied_store_boundary_test.go') == source['fixture_sha256']
assert compiled.pop('server/filestore.go') == change['modified_sha256']
assert compiled == {n:h for n,h in upstream.items() if n != 'server/filestore.go'}
assert sha(root/'fixture.go') == source['fixture_sha256'] == sha(repo/'scripts/fixtures/nats-scheduling-store-boundary_test.go.txt')
assert sha(root/'runner.py') == source['runner_sha256']
assert read('command.json') == ['go','test','-p=1','-json','./server','-run','^TestWorkflowCopiedSchedulingIndexBoundary$','-count=1','-timeout=3m']
events = [json.loads(l) for l in (root/'events.jsonl').read_text().splitlines()]
assert not any(e['Action'] in ('skip','fail','build-fail') for e in events)
assert all(e.get('Package') == 'github.com/nats-io/nats-server/v2/server' for e in events)
test = 'TestWorkflowCopiedSchedulingIndexBoundary'
for name in [test] + [f'{test}/{mode}/node-{node}' for mode in ('intact','removed') for node in range(3)]:
    selected = [e for e in events if e.get('Test') == name]
    assert sum(e['Action']=='run' for e in selected) == 1, name
    assert [e['Action'] for e in selected if e['Action'] in ('pass','fail','skip')] == ['pass'], name
assert [e['Action'] for e in events if not e.get('Test') and e['Action'] in ('pass','fail','skip')] == ['pass']
cells=[]
purges=0
for mode in ('intact','removed'):
    for node, count in enumerate((768,141,0)):
        key=f'{mode}-node-{node}'
        initial=read(key+'.json')
        assert initial['state']['messages']==count and initial['state']['last_seq']==2000000
        schedules=count if mode=='removed' else 0
        assert len(initial['schedules'])==schedules
        purge=read('subject-purge-'+key+'.json')
        assert len(purge['probes'])==count
        for p in purge['probes']:
            assert p['sequence']==p['lookup_sequence'] and p['purged']==1 and p['absent_after']
        purges+=len(purge['probes'])
        reopened=read('reopened-'+key+'.json')
        assert reopened['schedules']==schedules and reopened['absent_sources']==count and reopened['clean_stop']
        resumed=read('resumed-'+key+'.json')
        assert resumed['schedules_before_resume']==schedules
        assert resumed['schedules_after_resume']==resumed['schedules_after_second_reopen']==resumed['target_callbacks']==0
        for state in (purge['after'],reopened['state'],resumed['state']):
            assert state['messages']==0 and state['first_seq']==2000001 and state['last_seq']==2000000
        cells.append(dict(copy=key,before=schedules,after=0,second_reopen=0,target_callbacks=0))
assert purges==1818
prior=repo/'docs/scale/million-timer-terminal-2026-10-02/scheduler-resume-boundary'
prior_manifest=json.loads((prior/'manifest.json').read_text())
with tarfile.open(prior/'originals.tar.gz','r:gz') as archive:
    raw={m.name:archive.extractfile(m).read() for m in archive if m.isfile()}
assert set(raw)==set(prior_manifest['files'])
assert all(hashlib.sha256(v).hexdigest()==prior_manifest['files'][n] for n,v in raw.items())
assert hashlib.sha256(raw['fixture.go']).hexdigest()==source['fixture_sha256']
for mode in ('intact','removed'):
    for node,count in enumerate((768,141,0)):
        old=json.loads(raw[f'resumed-{mode}-node-{node}.json'])
        expected=count if mode=='removed' else 0
        assert old['schedules_before_resume']==old['schedules_after_second_reopen']==expected
        assert old['schedules_after_resume']==old['target_callbacks']==0
result=dict(verdict='accepted isolated copied-store dirty-count control', original_files_unchanged=len(before), module_files_verified=len(upstream), modified_upstream_files=['server/filestore.go'], exact_source_change_verified=True, actual_cases=6, exact_subject_purges=purges, cells=cells, scope='Direct file-store loop, no server or Raft; original missed-retirement cause remains unconfirmed; no production dependency change.')
result['original_failed_baseline_archive_verified']=True
(root/'independent-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
