package server

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// This diagnostic opens only copies supplied by the external runner. Recovery
// mode keeps scheduling paused: there is no server, Raft, callback or publication.
func TestWorkflowCopiedSchedulingIndexBoundary(t *testing.T) {
	root := os.Getenv("WF_COPIED_STORE_BOUNDARY_ROOT")
	if root == "" {
		t.Fatal("copied-store root required")
	}
	for _, mode := range []string{"intact", "removed"} {
		for node, expected := range []uint64{768, 141, 0} {
			t.Run(fmt.Sprintf("%s/node-%d", mode, node), func(t *testing.T) {
				dir := filepath.Join(root, "copies", mode, fmt.Sprintf("node-%d", node))
				raw, err := os.ReadFile(filepath.Join(dir, "meta.inf"))
				if err != nil {
					t.Fatal(err)
				}
				var meta struct {
					StreamConfig
					Created time.Time
				}
				if err := json.Unmarshal(raw, &meta); err != nil {
					t.Fatal(err)
				}
				if meta.Name != "WF_RUN" || !meta.AllowMsgSchedules || meta.Storage != FileStorage {
					t.Fatal("wrong source store")
				}
				fs, err := newFileStoreWithCreatedAndMode(FileStoreConfig{StoreDir: dir}, meta.StreamConfig, meta.Created, nil, nil, true)
				if err != nil {
					t.Fatal(err)
				}
				defer fs.Stop()
				state := fs.State()
				fs.mu.Lock()
				count := len(fs.scheduling.schedules)
				paused := fs.scheduling.paused
				schedules := make(map[string]uint64, count)
				for subject, schedule := range fs.scheduling.schedules {
					schedules[subject] = schedule.seq
				}
				fs.mu.Unlock()
				report := struct {
					Mode      string            `json:"mode"`
					Node      int               `json:"node"`
					State     StreamState       `json:"state"`
					Paused    bool              `json:"paused"`
					Schedules map[string]uint64 `json:"schedules"`
				}{mode, node, state, paused, schedules}
				data, err := json.MarshalIndent(report, "", "  ")
				if err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("%s-node-%d.json", mode, node)), data, 0644); err != nil {
					t.Fatal(err)
				}
				if state.Msgs != expected || state.LastSeq != 2000000 {
					t.Fatalf("physical messages=%d last=%d, want %d/2000000", state.Msgs, state.LastSeq, expected)
				}
				if !paused {
					t.Fatal("recovery scheduling must stay paused")
				}
				want := 0
				if mode == "removed" {
					want = int(expected)
				}
				if count != want {
					t.Fatalf("recovered schedules=%d want=%d", count, want)
				}
				for subject, seq := range schedules {
					msg, err := fs.LoadMsg(seq, nil)
					if err != nil || msg.subj != subject || string(getHeader(JSScheduleTarget, msg.hdr)) == "" {
						t.Fatalf("recovered source %s/%d invalid: %v", subject, seq, err)
					}
				}
			})
		}
	}
}
