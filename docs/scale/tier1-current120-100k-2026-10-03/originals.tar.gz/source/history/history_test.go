package history

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"
	"time"

	"js-wf/client"

	"github.com/anishathalye/porcupine"
)

func TestStartModelAcceptsOverlapAndRejectsDoubleStart(t *testing.T) {
	base := time.Date(2030, 1, 2, 3, 4, 5, 0, time.UTC)
	makeOperation := func(call, returned time.Duration, hash, status string) client.Operation {
		args, _ := json.Marshal(map[string]string{"type": "test", "id": "same", "input_hash": hash})
		result, _ := json.Marshal(map[string]any{"status": status, "inv_seq": 7})
		return client.Operation{InvokeTS: base.Add(call), ReturnTS: base.Add(returned), Op: "start", Args: args, Result: result}
	}
	good := []client.Operation{
		makeOperation(0, 10*time.Millisecond, "hash-a", "started"),
		makeOperation(5*time.Millisecond, 15*time.Millisecond, "hash-a", "already_started"),
		makeOperation(16*time.Millisecond, 20*time.Millisecond, "hash-b", "input_mismatch"),
	}
	if result, err := CheckStarts(good, time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("valid start history=%s err=%v", result, err)
	}
	broken := append([]client.Operation(nil), good...)
	broken[1] = makeOperation(5*time.Millisecond, 15*time.Millisecond, "hash-a", "started")
	if result, err := CheckStarts(broken, time.Second); err != nil || result != porcupine.Illegal {
		t.Fatalf("double start history=%s err=%v", result, err)
	}
	lostAck := []client.Operation{makeOperation(0, 10*time.Millisecond, "hash-a", "already_started"), makeOperation(11*time.Millisecond, 15*time.Millisecond, "hash-b", "input_mismatch")}
	if result, err := CheckStarts(lostAck, time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("self-observed lost ack history=%s err=%v", result, err)
	}
	priorAck := []client.Operation{makeOperation(0, 10*time.Millisecond, "hash-a", "already_started"), makeOperation(11*time.Millisecond, 15*time.Millisecond, "hash-a", "started")}
	if result, err := CheckStarts(priorAck, time.Second); err != nil || result != porcupine.Illegal {
		t.Fatalf("start after completed prior ack history=%s err=%v", result, err)
	}
	unknown := makeOperation(0, 10*time.Millisecond, "hash-a", "unknown")
	unknown.Result = json.RawMessage(`{"status":"unknown","inv_seq":0}`)
	committed := []client.Operation{unknown, makeOperation(11*time.Millisecond, 15*time.Millisecond, "hash-a", "already_started")}
	if result, err := CheckStarts(committed, time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("unknown committed history=%s err=%v", result, err)
	}
	notCommitted := []client.Operation{unknown, makeOperation(11*time.Millisecond, 15*time.Millisecond, "hash-b", "started")}
	if result, err := CheckStarts(notCommitted, time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("unknown absent history=%s err=%v", result, err)
	}
	impossible := []client.Operation{unknown, makeOperation(11*time.Millisecond, 15*time.Millisecond, "hash-b", "already_started"), makeOperation(16*time.Millisecond, 20*time.Millisecond, "hash-a", "already_started")}
	if result, err := CheckStarts(impossible, time.Second); err != nil || result != porcupine.Illegal {
		t.Fatalf("impossible unknown history=%s err=%v", result, err)
	}
}

func TestRecorderExportsJSONLines(t *testing.T) {
	var recorder Recorder
	operation := client.Operation{InvokeTS: time.Now(), ReturnTS: time.Now().Add(time.Millisecond), Op: "getResult", Args: json.RawMessage(`{"type":"test","id":"one"}`), Result: json.RawMessage(`{"status":"completed"}`)}
	recorder.Record(operation)
	operation.Args[0] = '['
	snapshot := recorder.Snapshot()
	if len(snapshot) != 1 || snapshot[0].Args[0] != '{' {
		t.Fatalf("recorder did not isolate operation bytes: %+v", snapshot)
	}
	var output bytes.Buffer
	if err := recorder.WriteJSONL(&output); err != nil {
		t.Fatal(err)
	}
	if strings.Count(output.String(), "\n") != 1 || !strings.Contains(output.String(), `"getResult"`) {
		t.Fatalf("history export=%q", output.String())
	}
}

func TestStartModelChecksLargeConcurrentLeaderKillBurst(t *testing.T) {
	base := time.Date(2030, 1, 2, 3, 4, 5, 0, time.UTC)
	args := json.RawMessage(`{"type":"leaderkill","id":"same","input_hash":"hash-a"}`)
	makeOperation := func(index int, status string, seq uint64) client.Operation {
		result, err := json.Marshal(map[string]any{"status": status, "inv_seq": seq})
		if err != nil {
			t.Fatal(err)
		}
		return client.Operation{InvokeTS: base.Add(time.Duration(index) * time.Microsecond), ReturnTS: base.Add(50*time.Millisecond + time.Duration(index)*time.Microsecond), Op: "start", Args: args, Result: result}
	}
	operations := make([]client.Operation, 0, 500)
	for i := 0; i < 500; i++ {
		status, seq := "already_started", uint64(7)
		if i < 5 {
			status, seq = "unknown", 0
		} else if i == 250 {
			status = "started"
		}
		operations = append(operations, makeOperation(i, status, seq))
	}
	if result, err := CheckStarts(operations, 5*time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("large concurrent start history=%s err=%v", result, err)
	}
	enqueueUnknown := append([]client.Operation(nil), operations...)
	enqueueUnknown[250].Result = json.RawMessage(`{"status":"enqueue_unknown","inv_seq":7}`)
	if result, err := CheckStarts(enqueueUnknown, 5*time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("large concurrent enqueue-unknown history=%s err=%v", result, err)
	}
	selfObserved := append([]client.Operation(nil), operations...)
	selfObserved[250].Result = json.RawMessage(`{"status":"already_started","inv_seq":7}`)
	if result, err := CheckStarts(selfObserved, 5*time.Second); err != nil || result != porcupine.Ok {
		t.Fatalf("large self-observed lost-ack history=%s err=%v", result, err)
	}
	selfObservedWrong := append([]client.Operation(nil), selfObserved...)
	selfObservedWrong[6].Result = json.RawMessage(`{"status":"already_started","inv_seq":8}`)
	if result, err := CheckStarts(selfObservedWrong, 5*time.Second); err != nil || result != porcupine.Illegal {
		t.Fatalf("large inconsistent self-observed handles=%s err=%v", result, err)
	}
	tooEarly := append([]client.Operation(nil), operations...)
	tooEarly[6].ReturnTS = base.Add(100 * time.Microsecond)
	if result, err := CheckStarts(tooEarly, 5*time.Second); err != nil || result != porcupine.Illegal {
		t.Fatalf("duplicate returned before successful call=%s err=%v", result, err)
	}
	wrongSequence := append([]client.Operation(nil), operations...)
	wrongSequence[0].Result = json.RawMessage(`{"status":"already_started","inv_seq":8}`)
	if result, err := CheckStarts(wrongSequence, 5*time.Second); err != nil || result != porcupine.Illegal {
		t.Fatalf("mismatched duplicate handle=%s err=%v", result, err)
	}
}

func TestUniformStartBurstProofMatchesPorcupine(t *testing.T) {
	base := time.Date(2030, 1, 2, 3, 4, 5, 0, time.UTC)
	args := json.RawMessage(`{"type":"leaderkill","id":"same","input_hash":"hash-a"}`)
	for startedAt := 0; startedAt < 6; startedAt++ {
		for variant := 0; variant < 64; variant++ {
			operations := make([]client.Operation, 6)
			converted := make([]porcupine.Operation, 6)
			for i := range operations {
				status, seq := "already_started", uint64(7)
				if i == startedAt {
					status = "started"
					if variant&32 != 0 {
						status = "enqueue_unknown"
					}
				} else if variant&(1<<i) != 0 {
					status, seq = "unknown", 0
				}
				result, err := json.Marshal(map[string]any{"status": status, "inv_seq": seq})
				if err != nil {
					t.Fatal(err)
				}
				call := base.Add(time.Duration(i) * 10 * time.Microsecond)
				returned := base.Add(100 * time.Microsecond)
				if variant&1 != 0 && i < startedAt && status == "already_started" {
					returned = base.Add(time.Duration(i)*10*time.Microsecond + time.Microsecond)
				}
				operations[i] = client.Operation{InvokeTS: call, ReturnTS: returned, Op: "start", Args: args, Result: result}
				converted[i] = porcupine.Operation{Input: startInput{Type: "leaderkill", ID: "same", InputHash: "hash-a", HasConfirmedStart: true}, Output: startOutput{Status: status, InvSeq: seq}, Call: call.UnixNano(), Return: returned.UnixNano()}
			}
			want, err := CheckStarts(operations, time.Second)
			if err != nil {
				t.Fatal(err)
			}
			got, applicable := checkUniformStartBurst(converted)
			if !applicable || got != want {
				t.Fatalf("started_at=%d variant=%d direct=%s applicable=%t porcupine=%s", startedAt, variant, got, applicable, want)
			}
		}
	}
}

func TestUnconfirmedStartBurstProofMatchesPorcupine(t *testing.T) {
	base := time.Date(2030, 1, 2, 3, 4, 5, 0, time.UTC)
	args := json.RawMessage(`{"type":"leaderkill","id":"same","input_hash":"hash-a"}`)
	for variant := 0; variant < 64; variant++ {
		operations := make([]client.Operation, 6)
		converted := make([]porcupine.Operation, 6)
		for i := range operations {
			status, seq := "already_started", uint64(7)
			if variant&(1<<i) != 0 {
				status, seq = "unknown", 0
			}
			result, err := json.Marshal(map[string]any{"status": status, "inv_seq": seq})
			if err != nil {
				t.Fatal(err)
			}
			call := base.Add(time.Duration(i) * 10 * time.Microsecond)
			returned := base.Add(100 * time.Microsecond)
			operations[i] = client.Operation{InvokeTS: call, ReturnTS: returned, Op: "start", Args: args, Result: result}
			converted[i] = porcupine.Operation{Input: startInput{Type: "leaderkill", ID: "same", InputHash: "hash-a"}, Output: startOutput{Status: status, InvSeq: seq}, Call: call.UnixNano(), Return: returned.UnixNano()}
		}
		want, err := CheckStarts(operations, time.Second)
		if err != nil {
			t.Fatal(err)
		}
		got, applicable := checkUniformStartBurst(converted)
		if !applicable || got != want {
			t.Fatalf("variant=%d direct=%s applicable=%t porcupine=%s", variant, got, applicable, want)
		}
	}
}
