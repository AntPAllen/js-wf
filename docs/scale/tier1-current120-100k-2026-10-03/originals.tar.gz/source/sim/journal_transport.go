package sim

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"sync"
	"time"

	"js-wf/journal"

	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
)

type AppendFault string

const (
	DropBeforeCommit   AppendFault = "drop_before_commit"
	LoseAckAfterCommit AppendFault = "lose_ack_after_commit"
	RejectUnchanged    AppendFault = "reject_unchanged_tail"
	CompetingCommit    AppendFault = "competing_commit"
)

var ErrTransportLost = errors.New("simulated transport lost")

type Fault struct {
	Kind          AppendFault
	CompetingData []byte
}

type Message struct {
	Subject  string
	Sequence uint64
	Data     []byte
}

// JournalTransport models only the stream operations required by
// journal.Append. It preserves global stream sequences and each subject tail.
// Faults are consumed in publish order; callers can choose their order through
// Scheduler rather than relying on Go goroutine timing.
type JournalTransport struct {
	mu          sync.Mutex
	schedule    *Scheduler
	sequence    uint64
	messages    map[string][]Message
	faults      []Fault
	batchFaults []BatchReadFault
	nextFaults  []NextReadFault
	lastFault   bool
}

var _ journal.AppendPort = (*JournalTransport)(nil)
var _ journal.ReadPort = (*JournalTransport)(nil)
var _ journal.BatchReadPort = (*JournalTransport)(nil)

func NewJournalTransport(schedule *Scheduler) *JournalTransport {
	return &JournalTransport{schedule: schedule, messages: map[string][]Message{}}
}

// PurgeBefore removes one subject's retained prefix while preserving global
// sequence numbers and appends that landed after the fixed sequence bound.
func (m *JournalTransport) PurgeBefore(subject string, before uint64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	list := m.messages[subject]
	cut := 0
	for cut < len(list) && list[cut].Sequence < before {
		cut++
	}
	m.messages[subject] = append([]Message(nil), list[cut:]...)
	m.event(TransportEvent{Operation: "purge_journal_prefix", Subject: subject, Sequence: before, Outcome: "ok"})
}

// DeleteMessage removes one retained message without renumbering later
// stream sequences, matching a JetStream message deletion.
func (m *JournalTransport) DeleteMessage(subject string, sequence uint64) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	list := m.messages[subject]
	for i, message := range list {
		if message.Sequence == sequence {
			m.messages[subject] = append(list[:i:i], list[i+1:]...)
			m.event(TransportEvent{Operation: "delete_journal_message", Subject: subject, Sequence: sequence, Outcome: "ok"})
			return true
		}
	}
	m.event(TransportEvent{Operation: "delete_journal_message", Subject: subject, Sequence: sequence, Outcome: "not_found"})
	return false
}

func (m *JournalTransport) QueueFault(f Fault) error {
	switch f.Kind {
	case DropBeforeCommit, LoseAckAfterCommit, RejectUnchanged:
		if len(f.CompetingData) != 0 {
			return fmt.Errorf("unexpected competing data for fault %s", f.Kind)
		}
	case CompetingCommit:
		if len(f.CompetingData) == 0 {
			return fmt.Errorf("competing commit has no data")
		}
	default:
		return fmt.Errorf("unknown append fault %q", f.Kind)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	f.CompetingData = append([]byte(nil), f.CompetingData...)
	m.faults = append(m.faults, f)
	return nil
}

// QueueLastFault drops one subject-tail lookup before any CAS publish.
func (m *JournalTransport) QueueLastFault() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.lastFault = true
}

func (m *JournalTransport) Last(ctx context.Context, subject string) (journal.AppendTail, error) {
	if err := ctx.Err(); err != nil {
		return journal.AppendTail{}, err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.lastFault {
		m.lastFault = false
		m.event(TransportEvent{Operation: "last", Subject: subject, Outcome: "transient_unavailable"})
		return journal.AppendTail{}, ErrTransportLost
	}
	list := m.messages[subject]
	if len(list) == 0 {
		m.event(TransportEvent{Operation: "last", Subject: subject, Outcome: "not_found"})
		return journal.AppendTail{}, jetstream.ErrMsgNotFound
	}
	last := list[len(list)-1]
	m.event(TransportEvent{Operation: "last", Subject: subject, Sequence: last.Sequence, DataSHA256: digest(last.Data), Outcome: "ok"})
	return journal.AppendTail{Sequence: last.Sequence, Data: append([]byte(nil), last.Data...)}, nil
}

func (m *JournalTransport) Next(ctx context.Context, subject string, from uint64) (journal.AppendTail, error) {
	if err := ctx.Err(); err != nil {
		return journal.AppendTail{}, err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.nextFaults) > 0 && m.nextFaults[0].Sequence == from {
		fault := m.nextFaults[0]
		m.nextFaults = m.nextFaults[1:]
		if fault.Kind == "timeout" {
			if err := m.schedule.AdvanceMillis(2000); err != nil {
				return journal.AppendTail{}, err
			}
		}
		m.event(TransportEvent{Operation: "next_journal", Subject: subject, Expected: from, Outcome: fault.Kind})
		switch fault.Kind {
		case "timeout":
			return journal.AppendTail{}, context.DeadlineExceeded
		case "no_responders":
			return journal.AppendTail{}, nats.ErrNoResponders
		case "unavailable":
			return journal.AppendTail{}, &jetstream.APIError{ErrorCode: 10008}
		case "direct_unavailable":
			return journal.AppendTail{}, errors.New("nats: JetStream system temporarily unavailable")
		case "wrapped_direct_unavailable":
			return journal.AppendTail{}, fmt.Errorf("read reply: %w", errors.New("nats: JetStream system temporarily unavailable"))
		case "unavailable_lookalike":
			return journal.AppendTail{}, errors.New("invalid journal: nats: JetStream system temporarily unavailable")
		}
	}
	// Appends are ordered by global sequence; purge and deletion preserve
	// that order. Seeking avoids rescanning the prefix for every entry of
	// a large parent replay without changing its modeled transport events.
	list := m.messages[subject]
	index := sort.Search(len(list), func(i int) bool { return list[i].Sequence >= from })
	if index < len(list) {
		message := list[index]
		m.event(TransportEvent{Operation: "next_journal", Subject: subject, Expected: from, Sequence: message.Sequence, DataSHA256: digest(message.Data), Outcome: "ok"})
		return journal.AppendTail{Sequence: message.Sequence, Data: append([]byte(nil), message.Data...)}, nil
	}
	m.event(TransportEvent{Operation: "next_journal", Subject: subject, Expected: from, Outcome: "not_found"})
	return journal.AppendTail{}, jetstream.ErrMsgNotFound
}

func (m *JournalTransport) Publish(ctx context.Context, subject string, data []byte, expected uint64) (uint64, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	event := TransportEvent{Operation: "publish", Subject: subject, Expected: expected, DataSHA256: digest(data)}
	var fault Fault
	if len(m.faults) != 0 {
		fault, m.faults = m.faults[0], m.faults[1:]
	}
	if fault.Kind == DropBeforeCommit {
		event.Outcome = string(fault.Kind)
		m.event(event)
		return 0, ErrTransportLost
	}
	if fault.Kind == RejectUnchanged {
		event.Outcome = string(fault.Kind)
		m.event(event)
		return 0, wrongLastSequence()
	}
	if fault.Kind == CompetingCommit {
		sequence := m.commit(subject, fault.CompetingData)
		m.event(TransportEvent{Operation: "injected_commit", Subject: subject, Sequence: sequence, DataSHA256: digest(fault.CompetingData), Outcome: string(fault.Kind)})
	}
	var current uint64
	list := m.messages[subject]
	if len(list) != 0 {
		current = list[len(list)-1].Sequence
	}
	if current != expected {
		event.Outcome = "wrong_last_sequence"
		m.event(event)
		return 0, wrongLastSequence()
	}
	seq := m.commit(subject, data)
	event.Sequence = seq
	if fault.Kind == LoseAckAfterCommit {
		event.Outcome = string(fault.Kind)
		m.event(event)
		return 0, ErrTransportLost
	}
	event.Outcome = "ok"
	m.event(event)
	return seq, nil
}

func (m *JournalTransport) Wait(ctx context.Context, delay time.Duration) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if delay < 0 || delay%time.Millisecond != 0 {
		return fmt.Errorf("invalid virtual delay %s", delay)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.schedule.AdvanceMillis(delay.Milliseconds()); err != nil {
		return err
	}
	m.event(TransportEvent{Operation: "wait", Outcome: fmt.Sprintf("%dms", delay.Milliseconds())})
	return nil
}

func (m *JournalTransport) Messages(subject string) []Message {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := append([]Message(nil), m.messages[subject]...)
	for i := range out {
		out[i].Data = append([]byte(nil), out[i].Data...)
	}
	return out
}

func (m *JournalTransport) commit(subject string, data []byte) uint64 {
	m.sequence++
	m.messages[subject] = append(m.messages[subject], Message{Subject: subject, Sequence: m.sequence, Data: append([]byte(nil), data...)})
	return m.sequence
}

func (m *JournalTransport) event(event TransportEvent) {
	event.AtMillis = m.schedule.NowMillis()
	m.schedule.RecordTransport(event)
}

func digest(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

func wrongLastSequence() error {
	return &jetstream.APIError{Code: 400, ErrorCode: jetstream.JSErrCodeStreamWrongLastSequenceConstant, Description: "wrong last sequence"}
}

type NextReadFault struct {
	Sequence uint64
	Kind     string
}

func (m *JournalTransport) QueueNextFault(fault NextReadFault) error {
	if fault.Sequence == 0 {
		return fmt.Errorf("next-read fault requires a sequence")
	}
	switch fault.Kind {
	case "timeout", "no_responders", "unavailable", "direct_unavailable", "wrapped_direct_unavailable", "unavailable_lookalike":
	default:
		return fmt.Errorf("unknown next-read fault %q", fault.Kind)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.nextFaults = append(m.nextFaults, fault)
	return nil
}
