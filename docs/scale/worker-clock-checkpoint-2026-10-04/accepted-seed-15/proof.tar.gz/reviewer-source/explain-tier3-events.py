#!/usr/bin/env python3
"""Explain recorded repair/fencing decisions; never certify the full soak."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path

FENCING = {
    'lease_initialization_lost': 'Lease initialization did not confirm ownership; the delivery retries.',
    'lease_heartbeat_lost': 'Heartbeat renewal could not confirm continuing ownership and returned ErrLost; processing was canceled.',
    'lease_execution_lost': 'Execution renewal could not confirm ownership and returned ErrLost; the worker stops this delivery.',
    'journal_stale': 'The journal rejected this owner’s epoch or expected tail; the delivery retries.',
    'lease_release_lost': 'The initial lease release returned ErrLost; subsequent cleanup cannot erase the lost ownership observation.',
    'lease_cleanup_lost': 'Lease cleanup returned ErrLost; cleanup must preserve successor safety.',
}
REPAIRS = {
    ('timer','timer'): 'A retained incomplete sleep request was due; the scanner attempted its journal-sequence wakeup.',
    ('timer','timer_start'): 'A retained timer creation request was due and incomplete; the scanner attempted its journal-sequence wakeup.',
    ('timer','timer_await'): 'A retained timer await request was due and incomplete; the scanner attempted its journal-sequence wakeup.',
    ('fallback-timer','due_fallback_timer'): 'A retained non-retired fallback timer was due; the scanner attempted a generation/step-specific wakeup before deleting the timer record.',
    ('start', 'missing_journal'): 'A retained invocation had no journal; the scanner attempted a deduplicated start wakeup.',
    ('signal', 'unconsumed_signal_nonterminal_generation'): 'A retained signal was unconsumed in a nonterminal journal and matched the current invocation generation; the scanner attempted a signal wakeup.',
    ('suspended', 'signal'): 'A suspended signal wait had an available signal; the scanner attempted a wakeup using its journal tail and retry window.',
    ('suspended', 'timer'): 'A suspended timer wait was due; the scanner attempted a wakeup using its journal tail and retry window.',
    ('suspended', 'select'): 'At least one case of a suspended select was ready; the scanner attempted a wakeup using its journal tail and retry window.',
    ('suspended', 'continuation'): 'A committed continuation was ready to resume; the scanner attempted a wakeup using its journal tail and retry window.',
}


def stamp(value):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('event timestamp lacks a timezone')


def check(metrics, fencing, repairs, expected_workers=None):
    if expected_workers is None:
        if not isinstance(metrics, list) or len(metrics) != 5:
            raise ValueError('expected five worker metric records')
        expected = {f'tier3-mixed-{i}': m['fencing_events'] for i, m in enumerate(metrics)}
    else:
        expected = expected_workers
    observed = Counter()
    explanations = []
    for index, event in enumerate(fencing or []):
        reason = event.get('Reason')
        if reason not in FENCING or event.get('Worker') not in expected:
            raise ValueError('unknown fencing reason or worker')
        if not all(event.get(k) for k in ('At', 'Type', 'ID', 'Error', 'RunSequence', 'Delivery')):
            raise ValueError('missing fencing evidence')
        if reason != 'lease_initialization_lost' and event.get('Epoch', 0) <= 0:
            raise ValueError('missing fenced ownership epoch')
        stamp(event['At'])
        observed[event['Worker']] += 1
        explanations.append(dict(kind='fencing', index=index, evidence=event, explanation=FENCING[reason]))
    if any(count is not None and observed[worker] != count for worker, count in expected.items()):
        raise ValueError('fencing records disagree with worker counters')
    repair_counts = Counter()
    for index, event in enumerate(repairs or []):
        key = (event.get('kind'), event.get('reason'))
        outcome = event.get('outcome')
        if key not in REPAIRS or outcome not in ('acknowledged', 'uncertain', 'dry_run'):
            raise ValueError('unknown repair reason or outcome')
        if not all(event.get(k) for k in ('at', 'type', 'id')):
            raise ValueError('missing repair invocation or timestamp')
        stamp(event['at'])
        if (outcome == 'uncertain') != bool(event.get('error')):
            raise ValueError('repair publication uncertainty was erased or invented')
        if event['kind'] == 'suspended':
            if event.get('journal_sequence', 0) <= 0 or (outcome != 'dry_run' and event.get('retry_window', 0) <= 0):
                raise ValueError('missing suspended journal tail or retry window')
        elif event.get('source_sequence', 0) <= 0 or event.get('invocation_sequence', 0) <= 0:
            raise ValueError('missing repair source or invocation generation')
        if event['kind'] in ('timer','fallback-timer'):
            if not event.get('fire_at'):raise ValueError('missing timer due-time evidence')
            stamp(event['fire_at'])
            if event['kind']=='timer' and event.get('journal_sequence',0)<=0:raise ValueError('missing pending timer journal sequence')
            if event['kind']=='fallback-timer' and (type(event.get('timer_step')) is not int or event['timer_step']<0):raise ValueError('missing fallback timer step')
        suffix = {
            'acknowledged': ' Publication was acknowledged; message-ID deduplication can make this a repeated wakeup.',
            'uncertain': ' Publication did not return a successful acknowledgment; it may have committed and needs a safe retry.',
            'dry_run': ' This was a dry-run decision; no publication was attempted.',
        }[outcome]
        explanations.append(dict(kind='repair', index=index, evidence=event, explanation=REPAIRS[key]+suffix))
        repair_counts[f'{event["kind"]}/{outcome}'] += 1
    return dict(scope='recorded R5 worker and repair decisions',
                counter_cross_checks_complete=all(v is not None for v in expected.values()),
                fencing_records=sum(observed.values()), repair_records=sum(repair_counts.values()),
                fencing_per_worker=dict(observed), repairs_by_outcome=dict(repair_counts),
                explanations=explanations, server_root_causes_confirmed=False,
                independently_reaudits_server_state=False, clears_full_tier3_release=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    names = ('worker-metrics.json', 'fencing.json', 'repairs.json')
    blobs = [(args.root/name).read_bytes() for name in names]
    expected_workers=None
    process_file=args.root/'process-evidence.json'
    if process_file.exists():
        names=names+('process-evidence.json',)
        process_blob=process_file.read_bytes()
        sessions=json.loads(process_blob)
        expected_workers={s['worker_id']:s['final_metrics']['fencing_events'] if s.get('final_metrics') is not None else None for s in sessions}
        if len(expected_workers)!=len(sessions) or sum(v is not None for v in expected_workers.values())!=5:
            raise ValueError('missing or duplicate graceful process counter snapshots')
        result=check(*(json.loads(blob) for blob in blobs),expected_workers=expected_workers)
        result['complete_hard_kill_attribution']=False
        blobs.append(process_blob)
    else:
        result=check(*(json.loads(blob) for blob in blobs))
    result['input_sha256'] = {name: hashlib.sha256(blob).hexdigest() for name, blob in zip(names, blobs)}
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'explanations'}, indent=2))
