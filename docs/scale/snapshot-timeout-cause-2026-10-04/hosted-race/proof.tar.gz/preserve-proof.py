import pathlib,json,hashlib,subprocess,tarfile
repo=pathlib.Path('/home/exedev/js-wf');root=pathlib.Path('/tmp/js-wf-current-race-37172701931');out=repo/'docs/scale/snapshot-timeout-cause-2026-10-04/hosted-race';out.mkdir(exist_ok=True)
run=json.loads((root/'run.json').read_text());job=json.loads((root/'job.json').read_text());review=json.loads((root/'independent-review.json').read_text());source=review['source'];assert source=='283ba325c31fe67194f0a0d7e11665b0bea405ed';assert (run['status'],run['conclusion'])==('completed','success') and run['head_sha']==source and run['id']==37172701931;assert job['run_id']==run['id'] and job['head_sha']==source and job['id']==111348770188 and (job['status'],job['conclusion'])==('completed','success');assert review['accepted'] and review['race_instrumented']
artifacts=[a for page in json.loads((root/'artifacts.json').read_text()) for a in page['artifacts']];assert len(artifacts)==1;artifact=artifacts[0];assert artifact['id']==11293000901 and artifact['name']=='tier1-race-evidence' and not artifact['expired'] and artifact['workflow_run']['id']==run['id'] and artifact['workflow_run']['head_sha']==source
(root/'artifact.json').write_text(json.dumps(artifact,indent=2)+'\n')
names=subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines();selected=[n for n in names if (n.endswith('.go') and not n.endswith('_test.go')) or n in ('go.mod','go.sum','.github/workflows/tier1-race.yml','scripts/check-tier1-suite.py','scripts/check-tier1-race.py') or n.startswith('sim/')]
hashes={}
for n in selected:
 data=(repo/n).read_bytes();assert data==subprocess.check_output(['git','show',source+':'+n],cwd=repo),n;hashes[n]=hashlib.sha256(data).hexdigest()
(root/'runtime-equivalence.json').write_text(json.dumps(dict(executed_source=source,observed_main=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),all_selected_bytes_match=True,files=hashes,scope='All tracked non-test Go/module inputs, complete simulator corpus and Tier1 race producer/verifier; later unrelated integration tests and reviewer/workflow edits are excluded.'),indent=2)+'\n')
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
ledger={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()};archive=out/'proof.tar.gz.tmp'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  assert m.isfile() and m.name not in seen;seen.add(m.name);h=hashlib.sha256();f=t.extractfile(m)
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  assert h.hexdigest()==ledger[m.name]['sha256'] and m.size==ledger[m.name]['bytes'],m.name
assert seen==set(ledger)
for n,p in files.items():assert sha(p)==ledger[n]['sha256'],n
archive.rename(out/'proof.tar.gz');archive=out/'proof.tar.gz';(out/'manifest.json').write_text(json.dumps(dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,files=ledger,all_members_readback_sha_verified=True),indent=2)+'\n')
print(json.dumps(dict(source=source,source_files_verified=review['source_files_verified'],runtime_equivalence_inputs=len(hashes),members=len(ledger),archive_bytes=archive.stat().st_size,suite=review['suite']['per_workload_seed_proof']['completed_bodies']),indent=2))
