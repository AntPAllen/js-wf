import hashlib,json,os,pathlib,subprocess,time
repo=pathlib.Path('/home/exedev/js-wf');out=pathlib.Path('/dev/shm/js-wf-local-proof-sparse-20261004')
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert not git('status','--porcelain'),'source must be clean before local checkout reduction'
assert git('config','--bool','core.sparseCheckout') if False else True
head=git('rev-parse','HEAD');candidates=[]
for line in git('ls-tree','-rl','HEAD').splitlines():
 header,name=line.split('\t',1);mode,kind,oid,size=header.split();size=int(size)
 if name.startswith('docs/scale/') and size>=16*1024*1024 and ('.tar.gz' in name or name.rsplit('/',1)[-1].startswith('originals.part')):
  assert not any(x in name for x in '*?[\\\n')
  path=repo/name;assert path.is_file() and not path.is_symlink() and path.stat().st_size==size
  assert git('hash-object',str(path))==oid
  def digest_file(p):
   h=hashlib.sha256()
   with p.open('rb') as f:
    while b:=f.read(1024*1024):h.update(b)
   return h.hexdigest()
  digest=digest_file(path)
  p=subprocess.Popen(['git','cat-file','blob',oid],cwd=repo,stdout=subprocess.PIPE);h=hashlib.sha256();n=0
  while b:=p.stdout.read(1024*1024):h.update(b);n+=len(b)
  assert p.wait()==0 and n==size and h.hexdigest()==digest
  candidates.append(dict(path=name,bytes=size,git_blob=oid,sha256=digest,allocated_bytes=path.stat().st_blocks*512))
assert len(candidates)==55
names=git('ls-files').splitlines();source_names=[n for n in names if n.endswith(('.go','.py','.yml')) or n in ('go.mod','go.sum')]
def sources():return {n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in source_names}
before=sources();selected={str(repo/e['path']) for e in candidates}
for fd in pathlib.Path('/proc').glob('[0-9]*/fd/*'):
 try:p=os.readlink(fd)
 except OSError:continue
 assert p not in selected,(fd,p)
patterns='/*\n'+''.join('!/'+e['path']+'\n' for e in candidates)
(out/'patterns.txt').write_text(patterns)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
record=dict(verified_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),head=head,files=candidates,all_materialized_and_git_blob_sha256_match=True,source_inputs=len(before),local_checkout_only=True,physical_broker_stores_unchanged=True,qualification_unchanged=True,bytes_omitted=sum(e['bytes'] for e in candidates),allocated_bytes_reclaimed=sum(e['allocated_bytes'] for e in candidates),complete=False)
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=repo,input=patterns,text=True,check=True)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
assert all(not (repo/e['path']).exists() for e in candidates)
after=sources();assert after==before
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
record['complete']=True;record['source_pre_post_sha256_match']=True
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
