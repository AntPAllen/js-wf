from pathlib import Path
import gzip,hashlib,json,os,stat,time
roots=[Path('/tmp/js-wf-scale-live-1m-20260930')]
for root in roots:
 report=json.loads((root/'report.json').read_text());assert report['status']=='completed',root
 for fd in Path('/proc').glob('[0-9]*/fd/*'):
  try: target=os.readlink(fd)
  except OSError:continue
  assert not target.startswith(str(root)+'/'),(fd,target)
 files=sorted(p for p in root.glob('node-*/**/*') if p.is_file() and not p.is_symlink())
 archive=root/'broker-store-archive';archive.mkdir(exist_ok=False)
 manifest=archive/'manifest.jsonl'
 count=raw=compressed=0
 with manifest.open('w') as ledger:
  for p in files:
   before=p.stat();relative=p.relative_to(root);dest=archive/(str(relative)+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
   digest=hashlib.sha256()
   with p.open('rb') as reader,dest.open('wb') as writer:
    with gzip.GzipFile(filename='',mode='wb',compresslevel=1,mtime=0,fileobj=writer) as zipper:
     while chunk:=reader.read(1024*1024):digest.update(chunk);zipper.write(chunk)
    writer.flush();os.fsync(writer.fileno())
   verified=hashlib.sha256();size=0
   with gzip.open(dest,'rb') as reader:
    while chunk:=reader.read(1024*1024):verified.update(chunk);size+=len(chunk)
   after=p.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
   assert size==before.st_size and digest.digest()==verified.digest(),p
   entry={'original':str(relative),'archive':str(dest.relative_to(root)),'sha256':digest.hexdigest(),'bytes':size,'archive_bytes':dest.stat().st_size,'mtime_ns':before.st_mtime_ns,'mode':stat.S_IMODE(before.st_mode)}
   ledger.write(json.dumps(entry,separators=(',',':'))+'\n');ledger.flush();os.fsync(ledger.fileno())
   p.unlink();count+=1;raw+=size;compressed+=dest.stat().st_size
   if count%300==0:print(json.dumps({'root':str(root),'archived_files':count,'original_bytes':raw,'compressed_bytes':compressed}),flush=True)
 summary={'root':str(root),'report_sha256':hashlib.sha256((root/'report.json').read_bytes()).hexdigest(),'revision':report.get('revision'),'files':count,'original_bytes':raw,'compressed_bytes':compressed,'freed_bytes':raw-compressed,'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'all_decompressed_bytes_verified':True,'status':'complete'}
 (archive/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
