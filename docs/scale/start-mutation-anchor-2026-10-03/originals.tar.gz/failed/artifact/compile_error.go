package lease
invalid Go syntax
