import pathlib,json,hashlib,tarfile,re
repo=pathlib.Path('/home/exedev/js-wf');root=pathlib.Path('/dev/shm/js-wf-clock-reply-real-20261004');out=repo/'docs/scale/worker-clock-reply-identity-2026-10-04/real-api';out.mkdir(exist_ok=True)
before=json.loads((root/'source-before.json').read_text());after={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in before};assert after==before;(root/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
core=json.loads(pathlib.Path('/tmp/js-wf-current-race-37172701931/runtime-equivalence.json').read_text());assert len(core['files'])==685
for n,d in core['files'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==d,n
(root/'runtime-equivalence.json').write_text(json.dumps(dict(tested_source=core['executed_source'],all_685_runtime_simulator_producer_inputs_unchanged=True,files=core['files'],integration_fixture_changes_excluded=True),indent=2)+'\n')
runs=[]
for kind in ['normal','race']:
 text=(root/(kind+'.log')).read_text();matches=re.findall(r'real clock reply peer=(\d) sample=(\{[^\n]+\})',text);assert len(matches)==6;records=[dict(peer=int(peer),sample=json.loads(data)) for peer,data in matches];assert [r['sample']['sequence'] for r in records]==list(range(1,7));assert [r['peer'] for r in records]==[0,0,1,1,2,2];assert all(abs(r['sample']['offset_ns'])<1_000_000_000 for r in records);elapsed=re.search(r'ok\s+js-wf/integration\s+([\d.]+)s',text);assert elapsed and '--- PASS: TestMatrixWorkerClockReplyIdentityRealCluster' in text;runs.append(dict(mode=kind,package_seconds=float(elapsed[1]),samples=records,logical_messages=6,last_sequence=6))
for n in before:
 p=root/'executed-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/n).read_bytes())
analysis=dict(healthy_real_nodes=3,file_storage=True,replicas=3,per_run_probes=6,runs=runs,source_inputs_verified_before_after=len(before),all_685_runtime_simulator_producer_inputs_unchanged=True,actual_test_executables_retained=False,broker_stores_retained=False,stores_reopened=False,qualifies_five_container_fault_row=False,qualifies_full_matrix=False,old_timeout_server_cause_confirmed=False)
(root/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n');(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()};ledger={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()};tmp=out/'proof.tar.gz.tmp'
with tarfile.open(tmp,'w:gz') as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(tmp,'r:gz') as tar:
 for m in tar:
  assert m.isfile() and m.name not in seen;seen.add(m.name);h=hashlib.sha256();f=tar.extractfile(m)
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  assert h.hexdigest()==ledger[m.name]['sha256'] and m.size==ledger[m.name]['bytes'],m.name
assert seen==set(ledger)
for n,p in files.items():assert sha(p)==ledger[n]['sha256'],n
tmp.rename(out/'proof.tar.gz');archive=out/'proof.tar.gz';(out/'manifest.json').write_text(json.dumps(dict(files=ledger,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,all_members_readback_sha_verified=True),indent=2)+'\n');print(json.dumps(dict(members=len(ledger),archive_bytes=archive.stat().st_size,normal_seconds=runs[0]['package_seconds'],race_seconds=runs[1]['package_seconds'])))
