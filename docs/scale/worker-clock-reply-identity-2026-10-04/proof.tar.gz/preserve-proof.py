import pathlib,json,hashlib,subprocess,tarfile
repo=pathlib.Path('/home/exedev/js-wf');root=pathlib.Path('/dev/shm/js-wf-clock-reply-identity-20261004');out=repo/'docs/scale/worker-clock-reply-identity-2026-10-04';failure=pathlib.Path('/dev/shm/js-wf-tier3-clock-failure-37164231641-111324439684');prefix='raw/tier3-matrix-range/seed-6/tier3-mixed-journal/';old_manifest=json.loads((repo/'docs/scale/worker-clock-checkpoint-2026-10-04/failed-shard-1-13/raw-manifest.json').read_text())['files'];samples=[]
for index in range(5):
 for suffix in ['-clock.json','.log']:
  name=f'matrix-process-{index}-generation-0'+suffix;p=failure/(prefix+name);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==old_manifest[prefix+name];dest=root/'failed-original'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
  if suffix=='-clock.json':samples.append(json.loads(data))
  else:assert 'worker clock proof: context deadline exceeded' in data.decode()
old_source='79915ca41a5c5a23b9997eea5f3f66d82530ee30';(root/'failed-campaign-clock-writer.go.txt').write_bytes(subprocess.check_output(['git','show',old_source+':integration/mixed_matrix_worker_clock_test.go'],cwd=repo));(root/'phase-review.json').write_text(json.dumps(dict(run=37164231641,job=111324439684,seed=6,source=old_source,all_five_initial_writes_succeeded=True,last_written_samples=samples,timeout_error_site='periodic ticker write, not initial synchronous write',publish_vs_read_unknown=True,server_cause_unconfirmed=True,raw_files_match_committed_failed_original_manifest=True),indent=2)+'\n')
before=json.loads((root/'source-before.json').read_text());assert {n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in before}==before
for n,d in json.loads((root/'runtime-equivalence.json').read_text())['files'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==d,n
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
ledger={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()};tmp=out/'proof.tar.gz.tmp'
with tarfile.open(tmp,'w:gz') as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n,recursive=False)
seen=set()
with tarfile.open(tmp,'r:gz') as tar:
 for m in tar:
  assert m.isfile() and m.name not in seen;seen.add(m.name);h=hashlib.sha256();f=tar.extractfile(m)
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  assert h.hexdigest()==ledger[m.name]['sha256'] and m.size==ledger[m.name]['bytes'],m.name
assert seen==set(ledger)
for n,p in files.items():assert sha(p)==ledger[n]['sha256'],n
tmp.replace(out/'proof.tar.gz');archive=out/'proof.tar.gz';(out/'manifest.json').write_text(json.dumps(dict(files=ledger,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,all_members_readback_sha_verified=True),indent=2)+'\n');print(json.dumps(dict(members=len(ledger),archive_bytes=archive.stat().st_size,phase_review='all five initial writes succeeded; later periodic timeout remains unconfirmed')))
