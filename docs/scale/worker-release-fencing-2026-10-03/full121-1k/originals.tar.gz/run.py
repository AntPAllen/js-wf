import os,json,hashlib,subprocess,time
from pathlib import Path
root=Path(__file__).parent
repo=Path('/home/exedev/js-wf')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
names=subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines()
def hashes():return {n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in names if n.endswith('.go') or n in ('go.mod','go.sum','scripts/check-tier1-suite.py') or n.startswith('sim/testdata/regressions/')}
before=hashes();(root/'source-before.json').write_text(json.dumps(dict(revision=revision,files=before),indent=2)+'\n');(root/'source.txt').write_text(revision+'\n')
env=dict(os.environ,GOMEMLIMIT='512MiB',GOMAXPROCS='2',SIM_SEEDS='1000',SIM_COVERAGE_SUMMARY='0')
listed=subprocess.check_output(['go','test','-p=1','./sim','-list','^Test'],cwd=repo,env=env,text=True)
(root/'list.log').write_text(listed);(root/'inventory.txt').write_text('\n'.join(l for l in listed.splitlines() if l.startswith('Test') and l!='TestMain')+'\n')
(root/'seeded-inventory.txt').write_bytes(subprocess.check_output(['go','run','./scripts/tier1-seed-inventory'],cwd=repo,env=env))
(root/'regression-inventory.txt').write_text('\n'.join(sorted(n for n in before if n.startswith('sim/testdata/regressions/') and n.endswith('.json')))+'\n')
env.update(SIM_COVERAGE_SUMMARY='1',FAULT_TRACE_OUT=str(root/'failure.json'))
cmd=['go','test','-p=1','-json','./sim','-count=1','-timeout=5m'];(root/'command.json').write_text(json.dumps(cmd,indent=2)+'\n');started=time.monotonic()
with (root/'events.jsonl').open('w') as out,(root/'stderr.log').open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
(root/'execution.json').write_text(json.dumps(dict(returncode=r.returncode,wall_seconds=time.monotonic()-started),indent=2)+'\n')
after=hashes();(root/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
assert r.returncode==0,'suite execution rejected; original evidence retained'
subprocess.run(['python3','scripts/check-tier1-suite.py','--events',str(root/'events.jsonl'),'--inventory',str(root/'inventory.txt'),'--seeded-inventory',str(root/'seeded-inventory.txt'),'--regressions',str(root/'regression-inventory.txt'),'--source',str(root/'source.txt'),'--seeds','1000','--output',str(root/'result.json')],cwd=repo,check=True)
print((root/'result.json').read_text())
