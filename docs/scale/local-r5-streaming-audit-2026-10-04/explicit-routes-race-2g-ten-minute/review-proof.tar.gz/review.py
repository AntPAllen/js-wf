"""Verify complete combined audit ten-minute originals, executed source, SDK and raw models."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root = a.root.resolve()
def read(name):
    return json.loads((root / name).read_text())
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
def seconds(start, end):
    return (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds()

execution = read('execution.json')
assert execution['source'] == '0393caa467348cb555645e7fe2117a9ba8e5324e'
assert execution['status'] == 'row_verified' and execution['test_exit_code'] == 0
assert execution['duration'] == '10m' and execution['row'] == 'journal'
assert execution['explicit_route_seeds']
assert execution['seed'] == 1 and execution['race'] and execution['retained_audit_trace'] and not execution['batched_retained_audit'] and execution['streaming_state_retained_audit'] and execution['memory_limit']=='2GiB'
manifest = read('archive-manifest.json')
archive = root / 'originals.tar.gz'
assert sha(archive) == manifest['archive_sha256']
seen = set()
member_bytes = 0
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name in manifest['files'] and member.name not in seen
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        seen.add(member.name)
        h = hashlib.sha256()
        count = 0
        with tar.extractfile(member) as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
                count += len(block)
        assert count == member.size and h.hexdigest() == manifest['files'][member.name], member.name
        member_bytes += count
assert seen == set(manifest['files'])
# Trace assertions below apply to original bytes, not editable local substitutes.
for name in ['execution.json', 'binary.json', 'source-before.json', 'source-after.json', 'events.jsonl', 'fixture/checkpoint-audits.json'] + ['actual-sdk.json','result.json']:
    assert sha(root / name) == manifest['files'][name], name
before, after = read('source-before.json'), read('source-after.json')
assert before == after and before['revision'] == execution['source']
for name, digest in before['files'].items():
    assert manifest['files']['source/' + name] == digest
    assert hashlib.sha256(subprocess.check_output(['git', 'show', execution['source'] + ':' + name], cwd=a.repo)).hexdigest() == digest, name
binary = read('binary.json')
assert binary['race'] and '-race=true' in binary['build_info']
assert sha(root / 'integration.test') == binary['sha256'] == manifest['files']['integration.test']
actual = subprocess.check_output(['go', 'version', '-m', str(root / 'integration.test')], text=True).splitlines()
recorded = binary['build_info'].splitlines()
assert actual[0].split(': ', 1)[1] == recorded[0].split(': ', 1)[1]
assert actual[1:] == recorded[1:]
live=read('actual-sdk.json');assert live['sha256']==binary['sha256']
expected=read('test-environment.json');assert all(live['environment'].get(k)==v for k,v in expected.items())
assert expected['WF_TIER3_STREAMING_STATE_RETAINED_AUDIT']=='1' and expected['GOMEMLIMIT']=='2GiB' and expected['GOMAXPROCS']=='2'
info=live['build_info'].splitlines();assert info[0].split(': ',1)[1]==actual[0].split(': ',1)[1] and info[1:]==actual[1:]
for pid in [execution['supervisor_pid'],execution['test_pid'],live['pid']]:assert not Path('/proc',str(pid)).exists()
for name,digest in manifest['files'].items():assert sha(root/name)==digest,name
events=[json.loads(line) for line in (root/'events.jsonl').read_text().splitlines()]
results={e['Test']:e['Action'] for e in events if e['Action'] in ['pass','fail','skip'] and 'Test' in e}
assert results=={'TestFiveContainerMixedJournalLeaderEveryThirtySeconds':'pass'}
review=a.output.parent
source=root/'source'
subprocess.run(['python3','scripts/check-tier3-journal-row.py','--root',str(root/'fixture'),'--events',str(root/'events.jsonl'),'--row','journal','--duration','10m','--expected-seed','1','--require-checkpoint-audits','--output',str(review/'row-result.json')],cwd=source,check=True)
row=json.loads((review/'row-result.json').read_text());assert row==read('result.json')
assert row['invocations']>0 and row['invocations']%28==0 and row['journal_entries']>=4*row['invocations'] and row['confirmed_faults']==19
assert row['checkpoint_audit_checks']['all_expected_checkpoints_present']
budgets=[];audits=read('fixture/checkpoint-audits.json')
assert [c['batch'] for c in audits]==list(range(10,row['invocations']//28+1,10))
for c in audits:
 assert not c.get('error') and c['report']['Invocations']==c['report']['Journals']==c['report']['Terminal']==c['batch']*28
 assert 1<=len(c['attempts'])<=3 and seconds(c['started'],c['completed'])<60
 for attempt in c['attempts']:
  budget=seconds(attempt['started'],attempt['deadline']);assert 0<budget<=20.001;budgets.append(seconds(attempt['started'],attempt['completed']))
faults=read('fixture/faults.json');assert len(faults)==19
censuses=[]
for index,fault in enumerate(faults,1):
 name=f'fixture/fault-{index}-route-census.json'
 assert sha(root/name)==manifest['files'][name]
 rows=read(name);assert len(rows)==5 and {row['node'] for row in rows}==set(range(5))
 names={row['census']['server_name'] for row in rows};ids={row['census']['server_id'] for row in rows}
 assert len(names)==len(ids)==5 and '' not in names and '' not in ids
 for observation in rows:
  census=observation['census'];assert not observation.get('error')
  assert seconds(observation['before'],observation['after'])>=0 and seconds(fault['healed'],observation['before'])>=0
  assert census['connections']==sum(census['peers'].values())
  assert set(census['missing_peers'])==names-{census['server_name']}-set(census['peers'])
  assert census['full_mesh']==(len(census['missing_peers'])==0)
 censuses.append(dict(fault=index,all_full_mesh=all(row['census']['full_mesh'] for row in rows),nodes=[dict(node=row['node'],connections=row['census']['connections'],peers=row['census']['peers'],missing=row['census']['missing_peers']) for row in rows]))
helper=subprocess.check_output(['git','show',execution['source']+':scripts/tier2-history-review.go.txt'],cwd=a.repo)
(review/'history-review.go').write_bytes(helper)
dependencies=subprocess.check_output(['go','list','-deps','-f','{{.Dir}}|{{join .GoFiles " "}}|{{join .CgoFiles " "}}','js-wf/history'],cwd=source,text=True)
inputs={'go.mod','go.sum'}
for line in dependencies.splitlines():
 directory,*groups=line.split('|');directory=Path(directory)
 if directory.is_relative_to(source):inputs.update(str((directory/name).relative_to(source)) for name in ' '.join(groups).split())
model_hashes={}
for name in sorted(inputs):
 digest=sha(source/name);assert digest==hashlib.sha256(subprocess.check_output(['git','show',execution['source']+':'+name],cwd=a.repo)).hexdigest()
 dest=review/'model-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((source/name).read_bytes());model_hashes[name]=digest
model=review/'history-review';command=['go','build','-p=1','-o',str(model),str(review/'history-review.go')]
subprocess.run(command,cwd=source,check=True)
model_info=subprocess.check_output(['go','version','-m',str(model)],text=True);(review/'model-build-info.txt').write_text(model_info)
model_command=[str(model),str(root/'fixture/history.jsonl')];history=subprocess.check_output(model_command,cwd=source,text=True)
assert history.count('verdict=Ok error=<nil>')==3 and all('verdict=Ok error=<nil>' in line for line in history.splitlines())
(review/'history-result.txt').write_text(history)
summary=dict(source=execution['source'],row='journal',seed=1,duration='10m',race=True,memory_limit='2GiB',named_test_seconds=next(e['Elapsed'] for e in events if e['Action']=='pass' and e.get('Test')),invocations=row['invocations'],journal_entries=row['journal_entries'],faults=row['confirmed_faults'],worst_terminal_type_p99=max(c['terminal_p99_seconds'] for c in row['cells'].values()),worst_progress_type_p99=max(c['progress_p99_seconds'] for c in row['cells'].values()),checkpoint_audits=len(audits),max_checkpoint_attempt_seconds=max(budgets),explicit_route_seeds=True,route_censuses=censuses,all_19_fault_censuses_full_mesh=all(c['all_full_mesh'] for c in censuses),actual_sdk_sha256=binary['sha256'],source_inputs=len(before['files']),all_local_inputs_match_executed_git=True,all_actual_build_info_fields_match=True,actual_live_sdk_identity_verified=True,all_sdk_supervisor_processes_terminal=True,all_original_member_hashes_verified=True,archive_members=len(seen),archive_member_bytes=member_bytes,archive_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'],raw_row_review_matches_original=True,model_dependency_sha256=model_hashes,actual_model_sha256=sha(model),model_commands=[command,model_command],all_three_models_exact_ok=True,history_output=history,physical_stores_reopened=False,qualifies_full_matrix=False,qualifies_24h_row=False,qualifies_this_explicit_route_race_ten_minute_row=True,qualifies_default_route_profile=False,scope='Complete explicit-route race2GiB combined audit journal/seed1/10m originals independently verified. Actual SDK/stores retained; derived census contains names/pool counts, decoder validates remote IDs but individual remote IDs not retained. No causal/default-profile/full matrix/24h qualification or independent physical store reopening.')
a.output.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['model_dependency_sha256','model_commands','history_output']},indent=2))
