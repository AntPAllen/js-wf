"""Verify complete combined audit ten-minute originals, executed source, SDK and raw models."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root = a.root.resolve()
def read(name):
    return json.loads((root / name).read_text())
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
def seconds(start, end):
    return (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds()

execution = read('execution.json')
assert execution['source'] == 'd7e075d8a1d2fce8b1b5c32e5a9f2d370213f83e'
assert execution['status'] == 'failed' and execution['test_exit_code'] == 1
assert execution['duration'] == '10m' and execution['row'] == 'journal'
assert execution['seed'] == 1 and execution['race'] and execution['retained_audit_trace'] and not execution['batched_retained_audit'] and execution['streaming_state_retained_audit'] and execution['memory_limit']=='2GiB'
manifest = read('archive-manifest.json')
archive = root / 'originals.tar.gz'
assert sha(archive) == manifest['archive_sha256']
seen = set()
member_bytes = 0
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name in manifest['files'] and member.name not in seen
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        seen.add(member.name)
        h = hashlib.sha256()
        count = 0
        with tar.extractfile(member) as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
                count += len(block)
        assert count == member.size and h.hexdigest() == manifest['files'][member.name], member.name
        member_bytes += count
assert seen == set(manifest['files'])
# Trace assertions below apply to original bytes, not editable local substitutes.
for name in ['execution.json', 'binary.json', 'source-before.json', 'source-after.json', 'events.jsonl', 'fixture/checkpoint-audits.json'] + ['actual-sdk.json']:
    assert sha(root / name) == manifest['files'][name], name
before, after = read('source-before.json'), read('source-after.json')
assert before == after and before['revision'] == execution['source']
for name, digest in before['files'].items():
    assert manifest['files']['source/' + name] == digest
    assert hashlib.sha256(subprocess.check_output(['git', 'show', execution['source'] + ':' + name], cwd=a.repo)).hexdigest() == digest, name
binary = read('binary.json')
assert binary['race'] and '-race=true' in binary['build_info']
assert sha(root / 'integration.test') == binary['sha256'] == manifest['files']['integration.test']
actual = subprocess.check_output(['go', 'version', '-m', str(root / 'integration.test')], text=True).splitlines()
recorded = binary['build_info'].splitlines()
assert actual[0].split(': ', 1)[1] == recorded[0].split(': ', 1)[1]
assert actual[1:] == recorded[1:]
live=read('actual-sdk.json');assert live['sha256']==binary['sha256']
expected=read('test-environment.json');assert all(live['environment'].get(k)==v for k,v in expected.items())
assert expected['WF_TIER3_STREAMING_STATE_RETAINED_AUDIT']=='1' and expected['GOMEMLIMIT']=='2GiB' and expected['GOMAXPROCS']=='2'
info=live['build_info'].splitlines();assert info[0].split(': ',1)[1]==actual[0].split(': ',1)[1] and info[1:]==actual[1:]
for pid in [execution['supervisor_pid'],execution['test_pid'],live['pid']]:assert not Path('/proc',str(pid)).exists()
for name,digest in manifest['files'].items():assert sha(root/name)==digest,name
events=[json.loads(line) for line in (root/'events.jsonl').read_text().splitlines()]
results={e['Test']:e['Action'] for e in events if e['Action'] in ['pass','fail','skip'] and 'Test' in e}
assert results=={'TestFiveContainerMixedJournalLeaderEveryThirtySeconds':'fail'}
logs=''.join(e.get('Output','') for e in events)
assert 'timed out waiting for five current replicas: WF_JRN:' in logs and 'Lag:9058' in logs
faults=read('fixture/faults.json');assert len(faults)==9 and faults[-1]['node']==3 and faults[-1]['healed']=='0001-01-01T00:00:00Z'
assert all(f['healed']!='0001-01-01T00:00:00Z' for f in faults[:-1])
operations=read('fixture/fault-9-journal-operations.json');assert [o['action'] for o in operations]==['sigkill_removed','restarted'] and all(o['node']==3 for o in operations)
audits=read('fixture/checkpoint-audits.json');assert [c['batch'] for c in audits]==[10,20,30,40]
budgets=[]
for c in audits:
 assert not c.get('error') and c['report']['Invocations']==c['report']['Journals']==c['report']['Terminal']==c['batch']*28
 assert 1<=len(c['attempts'])<=3 and seconds(c['started'],c['completed'])<60
 for attempt in c['attempts']:
  assert not attempt.get('error') and 0<seconds(attempt['started'],attempt['deadline'])<=20.001
  elapsed=seconds(attempt['started'],attempt['completed']);assert elapsed<20;budgets.append(elapsed)
assert audits[-1]['report']==dict(Invocations=1120,Journals=1120,Entries=12346,Terminal=1120)
diag=[name for name in manifest['files'] if name.startswith('fixture/fault-9-failure-node')];assert len(diag)==15
assert not subprocess.check_output(['docker','ps','--filter','name=js-wf-route-'+str(live['pid'])+'-','--format','{{.Names}}'],text=True).strip()
summary=dict(source=execution['source'],row='journal',seed=1,requested_duration='10m',race=True,memory_limit='2GiB',named_test_seconds=next(e['Elapsed'] for e in events if e['Action']=='fail' and e.get('Test')),status='failed',failure='Restarted WF_JRN replica not current at unchanged60s heal deadline; reported lag9058. Cause unconfirmed.',completed_faults=8,failed_fault=faults[-1],failed_node_operations=operations,checkpoint_audits=len(audits),max_checkpoint_attempt_seconds=max(budgets),last_completed_checkpoint=audits[-1]['report'],actual_sdk_sha256=binary['sha256'],source_inputs=len(before['files']),all_local_inputs_match_executed_git=True,all_actual_build_info_fields_match=True,actual_live_sdk_identity_verified=True,actual_environment_verified=True,all_sdk_supervisor_processes_terminal=True,all_fixture_containers_removed=True,all_original_member_hashes_verified=True,archive_members=len(seen),archive_member_bytes=member_bytes,archive_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'],diagnostic_files=diag,physical_stores_reopened=False,qualifies_full_matrix=False,qualifies_24h_row=False,qualifies_ten_minute_row=False,scope='Complete failed combined audit race2GiB journal originals retained. Four checkpoint audits pass; no complete-row/final-integrity/drain/model qualification. Actual SDK/stores retained, not reopened; replica failure cause unconfirmed.')
a.output.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
