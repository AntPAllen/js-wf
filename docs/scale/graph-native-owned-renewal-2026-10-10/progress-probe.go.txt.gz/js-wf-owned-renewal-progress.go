package main
import("context";"crypto/sha256";"encoding/hex";"encoding/json";"fmt";"os";"time";"github.com/nats-io/nats.go";"github.com/nats-io/nats.go/jetstream")
func hash(s string)string{h:=sha256.Sum256([]byte(s));return hex.EncodeToString(h[:])}
func main(){
 data,e:=os.ReadFile(os.Args[2]);if e!=nil{panic(e)}
 var input struct{Expires time.Time;Publication struct{Token string}}
 if e=json.Unmarshal(data,&input);e!=nil{panic(e)}
 nc,e:=nats.Connect(os.Args[1],nats.Timeout(3*time.Second));if e!=nil{panic(e)};defer nc.Close()
 js,e:=jetstream.New(nc);if e!=nil{panic(e)}
 c,cancel:=context.WithTimeout(context.Background(),15*time.Second);defer cancel()
 stream,e:=js.Stream(c,"COST_AUTH");if e!=nil{panic(e)}
 rows:=[]map[string]any{}
 for _,i:=range []int{0,128,1000,2500,5000,7500,9999}{
 h:=hash(fmt.Sprint("owned-cost-orphan",i));k:=hash("graph-authority/"+h+"/"+input.Publication.Token)
 msg,e:=stream.GetLastMsgForSubject(c,"wf.cost.blob."+k);if e!=nil{panic(e)}
 var record struct{Fence struct{Intents map[string]struct{Expires time.Time}}}
 if e=json.Unmarshal(msg.Data,&record);e!=nil{panic(e)}
 expiry:=record.Fence.Intents[input.Publication.Token].Expires
 rows=append(rows,map[string]any{"index":i,"sequence":msg.Sequence,"expiry":expiry,"target_expiry":expiry.Equal(input.Expires.Add(time.Hour)),"original_expiry":expiry.Equal(input.Expires)})
 }
 out:=map[string]any{"observed_utc":time.Now().UTC(),"api":"public GetLastMsgForSubject","read_only":true,"quorum_authority":false,"acceptance":false,"samples":rows}
 b,_:=json.MarshalIndent(out,"","  ");fmt.Println(string(b))
}
