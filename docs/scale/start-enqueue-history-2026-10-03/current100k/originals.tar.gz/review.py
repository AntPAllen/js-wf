from pathlib import Path
import json,hashlib,importlib.util,subprocess,sys,re
root=Path(sys.argv[1]);repo=Path(sys.argv[2]);read=lambda p:json.loads(p.read_text())
metadata=read(root/'terminal.json');source=(root/'tier1-source.txt').read_text().strip()
assert metadata['status']=='completed' and metadata['conclusion']=='success' and metadata['headSha']==source=='9de1e726f6633e29a52f8b7b45e44b4ae1ac08c4'
assert len(metadata['jobs'])==1 and metadata['jobs'][0]['name']=='sim' and metadata['jobs'][0]['status']=='completed' and metadata['jobs'][0]['conclusion']=='success'
spec=importlib.util.spec_from_file_location('suite',repo/'scripts/check-tier1-suite.py');suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
events=[json.loads(l) for l in (root/'tier1-events.jsonl').read_text().splitlines()]
report=suite.check(events,(root/'tier1-inventory.txt').read_text(),100000,source,(root/'tier1-regression-inventory.txt').read_text(),(root/'tier1-seeded-inventory.txt').read_text())
report['events_sha256']=hashlib.sha256((root/'tier1-events.jsonl').read_bytes()).hexdigest()
assert json.dumps(report,indent=2)+'\n'==(root/'tier1-result.json').read_text()
names=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'sim'],cwd=repo,text=True).splitlines()
assert ''.join(n+'\n' for n in sorted(names) if n.startswith('sim/testdata/regressions/') and n.endswith('.json'))==(root/'tier1-regression-inventory.txt').read_text()
top=[]
for n in names:
 if n.endswith('_test.go'):
  content=subprocess.check_output(['git','show',source+':'+n],cwd=repo,text=True)
  top+=re.findall(r'^func (Test\w+)\(t \*testing.T\)',content,re.M)
assert len(top)==len(set(top)) and set(top)==set((root/'tier1-inventory.txt').read_text().splitlines())
assert not subprocess.check_output(['git','diff',source,'--','sim','scripts/tier1-seed-inventory'],cwd=repo)
seeded=subprocess.check_output(['go','run','-p=1','./scripts/tier1-seed-inventory'],cwd=repo,text=True)
assert seeded==(root/'tier1-seeded-inventory.txt').read_text()
package=[e for e in events if not e.get('Test') and e['Action']=='pass'];assert len(package)==1
proof=report['per_workload_seed_proof'];assert proof['workloads']==121 and proof['first']==1 and proof['last']==100000
review=dict(accepted=True,source=source,source_test_names_verified=len(top),source_regression_inventory_verified=report['pinned_regressions_pass'],source_AST_seed_inventory_verified=True,report_regenerates_byte_identically=True,package_seconds=package[0]['Elapsed'],report=report,scope='Complete source-inventoried121 workload1..100000 campaign/269 pins and168 top-level passes at9de1e72; hosted compiler binary and before/after source hashes were not retained by this producer. Separate exact-source full1k/race evidence provides those narrower build checks. No full real matrix/24h acceptance.')
(root/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k!='report'},indent=2));print(json.dumps(report['aggregate_counts'],indent=2))
