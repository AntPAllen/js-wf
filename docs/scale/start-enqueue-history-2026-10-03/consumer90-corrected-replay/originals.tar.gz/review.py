from pathlib import Path
import json,hashlib,importlib.util,subprocess,sys,math,re
repo=Path(sys.argv[2]).resolve();root=Path(sys.argv[1]).resolve();read=lambda p:json.loads(p.read_text())
def load(name,file):
 s=importlib.util.spec_from_file_location(name,repo/'scripts'/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
campaign=load('campaign','check-matrix-campaign.py');execution=load('execution','check-matrix-result.py');clock=load('row','check-tier3-journal-row.py')
metadata=read(root/'terminal.json');revision=metadata['headSha']
assert metadata['status']=='completed' and metadata['conclusion']=='success'
assert revision=='c0dc4d707e3c4c9d04dfb189fda0f2da0d3fcb97'
assert {j['name'] for j in metadata['jobs']}=={'seeds','leader (90)'} and len(metadata['jobs'])==2
assert all(j['status']=='completed' and j['conclusion']=='success' for j in metadata['jobs'])
r=root/'matrix-consumer-90-10m';prefix='matrix-consumer-90-';test='TestMixedMatrixConsumerLeaderEveryThirtySeconds'
events=[json.loads(l) for l in (r/(prefix+'test.jsonl')).read_text().splitlines()]
assert not any(e['Action'] in ('skip','fail','build-fail') for e in events)
execution.check(events,test,'10m');log=''.join(e.get('Output','') for e in events)
report=campaign.check_seed(log,'consumer_leader',90,test)
fault_data=read(r/(prefix+'faults.json'));faults=fault_data['faults']
assert fault_data['seed']==90 and campaign.seconds(fault_data['duration'])==600 and len(faults)==report['faults']==19
previous=None
for fault in faults:
 scheduled,killed,healed=map(clock.timestamp_ns,[fault[k] for k in ('scheduled','killed','healed')])
 assert scheduled<=killed<=healed and type(fault['node']) is int and 0<=fault['node']<3 and not fault.get('error')
 if previous is not None:assert scheduled-previous==30_000_000_000
 previous=scheduled
for fault in faults:
 assert re.fullmatch(r'WF_P_\d{2}',fault['consumer']) and int(fault['consumer'][-2:])<64
 assert type(fault.get('pending',0)) is int and type(fault.get('ack_pending',0)) is int
 assert fault.get('pending',0)>=0 and fault.get('ack_pending',0)>=0 and fault.get('pending',0)+fault.get('ack_pending',0)>0
samples=read(r/(prefix+'latencies.json'));terminal={};progress={t:[] for t in campaign.TYPES}
last_deadline=clock.timestamp_ns(faults[-1]['healed'])+300_000_000_000
for sample in samples:
 typ,id,event=sample['type'],sample['id'],sample['event'];delay=sample['delay_ns']
 assert typ in campaign.TYPES and type(delay) is int and delay>=0
 enabled,observed=map(clock.timestamp_ns,[sample['enabled'],sample['observed']])
 assert observed-enabled==delay
 if event=='terminal':
  assert (typ,id) not in terminal and observed<=last_deadline
  terminal[typ,id]=delay
 else:progress[typ].append(delay)
def p99(values):return sorted(values)[(len(values)*99+99)//100-1]
def matches(ns,seconds):assert abs(ns-round(seconds*1e9))<=1
assert len(terminal)==report['invocations'];matches(p99(list(terminal.values())),report['terminal_p99_seconds'])
for typ in campaign.TYPES:
 values=[v for (t,id),v in terminal.items() if t==typ];cell=report['cells'][typ];pr=report['progress'][typ]
 assert len(values)==cell['invocations'] and len(progress[typ])==pr['events']
 matches(p99(values),cell['terminal_p99_seconds']);matches(p99(progress[typ]),pr['p99_seconds']);matches(max(progress[typ]),pr['max_seconds'])
 assert sum(v>=30_000_000_000 for v in progress[typ])==pr['above_30s']
# Execute all three production history models; require their source to match
# the recorded campaign revision before using the current checkout.
assert not subprocess.check_output(['git','diff',revision,'--','history','client','journal','identity','provision','wf'],cwd=repo)
utility=root/'history-review.go.txt'
# go run requires .go; keep the temporary executable source outside repo/docs.
import tempfile,os
with tempfile.TemporaryDirectory(prefix='tier2-history-review-') as temporary:
 go=Path(temporary)/'review.go';go.write_bytes(utility.read_bytes())
 result=subprocess.check_output(['go','run','-p=1',str(go),str(r/(prefix+'history.jsonl'))],cwd=repo,env=dict(os.environ,GOMEMLIMIT='512MiB',GOMAXPROCS='2'),text=True)
 operations=len((r/(prefix+'history.jsonl')).read_text().splitlines())
 assert result==''.join(f'whole {name} operations={operations} verdict=Ok error=<nil>\n' for name in ('starts','signals','results'))
(root/'history-review.log').write_text(result)
review=dict(accepted=True,revision=revision,requested_row='consumer',recorded_row='consumer_leader',seed=90,report=report,raw_latency_samples=len(samples),raw_faults_verified=len(faults),raw_history_operations=operations,all_three_current_source_identical_history_models_pass=True,confirmed_active_consumer_faults=len(faults),scope='One corrected ten-minute Tier2 replay with reported raw-state audit and named-test queue-drain completion; no physical stores uploaded, not an independent retained-store audit or full200-seed qualification.')
(root/'independent-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
