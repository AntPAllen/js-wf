from pathlib import Path
import shutil,importlib.util,json,tempfile,sys
src=Path(sys.argv[1]).resolve();repo=Path(sys.argv[2]).resolve()
spec=importlib.util.spec_from_file_location('reviewer',src/'reviewer.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=json.loads((src/'independent-review.json').read_text());checks=[]
with tempfile.TemporaryDirectory(prefix='cleanup-relocated-controls-') as temporary:
 root=Path(temporary)/'relocated';shutil.copytree(src,root)
 review=m.review(root,repo,True)
 # Cache availability is a property of the reviewing machine, not the archive.
 expected=dict(original);expected['module_cache_readback_at_review']=review['module_cache_readback_at_review']
 assert review==expected
 def rejects(name,mutate,undo):
  mutate()
  try:
   try:m.review(root,repo,True)
   except (AssertionError,FileNotFoundError):checks.append(name)
   else:raise AssertionError('negative control accepted: '+name)
  finally:undo()
 store=root/'dirty-control/store';saved=root/'dirty-control/store.saved'
 rejects('missing_retained_store',lambda:store.rename(saved),lambda:saved.rename(store))
 p=root/'dirty-control/command.json';old=p.read_bytes();data=json.loads(old);data['working_directory']='/other-root/dirty-control/nats-source'
 rejects('inconsistent_recorded_run_root',lambda:p.write_text(json.dumps(data)),lambda:p.write_bytes(old))
 p=root/'baseline/compiled-inventory.json';old=p.read_bytes();data=json.loads(old);data['server/filestore.go']='0'*64
 rejects('compiled_bytes_do_not_match_manifest',lambda:p.write_text(json.dumps(data)),lambda:p.write_bytes(old))
 p=root/'baseline/events.jsonl';old=p.read_bytes();events=[json.loads(l) for l in old.splitlines()]
 for e in events:
  if e['Action']=='fail':e['Action']='pass'
 rejects('baseline_missing_expected_failure',lambda:p.write_text('\n'.join(map(json.dumps,events))+'\n'),lambda:p.write_bytes(old))
 assert m.review(root,repo,True)==review
result=dict(accepted=True,relocated_review_matches=True,negative_controls_rejected=checks,originals_unchanged=True)
(src/'portable-review-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
