import pathlib,tarfile,hashlib,json,importlib.util
root=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('full','scripts/check-tier3-full-matrix.py');full=importlib.util.module_from_spec(spec);spec.loader.exec_module(full)
results={}
for mode,run in [('sigkill',37132399483),('ldm',37132401225)]:
 archive=pathlib.Path(f'/tmp/js-wf-r5-start-gap-{mode}-tenm-{run}/originals/rolling-originals.tar.gz');base=root/mode/'seed-1';fixture=base/'tier3-mixed-journal';fixture.mkdir(parents=True,exist_ok=True)
 with tarfile.open(archive) as tar:
  for member in tar:
   name=pathlib.Path(member.name)
   if not member.isfile() or name.is_absolute() or '..' in name.parts:raise ValueError('unsafe archive member')
   if name.suffix not in ('.json','.jsonl','.txt','.log','.conf'):continue
   target=base/name if name.name in ('tier3-mixed-journal-events.jsonl','tier3-mixed-journal-result.json') else fixture/name
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
 events=base/'tier3-mixed-journal-events.jsonl';output=root/f'{mode}-regenerated.json'
 try:full.verify_seed(events,output,'rolling_upgrade',1,'10m',False)
 except ValueError as err:negative=str(err)
 else:raise AssertionError('missing progress request unexpectedly regenerated report')
 result=full.verify_seed(events,output,'rolling_upgrade',1,'10m',False,True,mode)
 results[mode]=dict(run=run,original_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),prior_call_rejected=negative,corrected_report_identical=True,invocations=result['invocations'],confirmed_faults=result['confirmed_faults'],scan_progress=result['start_scan_progress_checks'],clears_new_workload_gate=False)
(root/'actual-controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
