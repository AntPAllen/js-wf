from pathlib import Path
import hashlib,json,tarfile
root=Path('/tmp/js-wf-journal-normal-2g-10m-20261004')
review=Path('/tmp/js-wf-journal-normal-2g-10m-review-20261004')
out=Path('/home/exedev/js-wf/docs/scale/local-r5-audit-memory-2026-10-04/normal-2g-ten-minute')
out.mkdir()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
summary=json.loads((review/'independent-review.json').read_text());assert summary['all_original_member_hashes_verified'] and summary['all_three_models_exact_ok']
parts=[];whole=hashlib.sha256()
with (root/'originals.tar.gz').open('rb') as f:
 while block:=f.read(25*1024*1024):
  name=f'originals.tar.gz.part-{len(parts):02d}';dest=out/name;dest.write_bytes(block);digest=hashlib.sha256(block).hexdigest();assert sha(dest)==digest
  whole.update(dest.read_bytes());parts.append(dict(name=name,bytes=len(block),sha256=digest))
assert whole.hexdigest()==summary['archive_sha256']==sha(root/'originals.tar.gz')
files={str(p.relative_to(review)):p for p in review.rglob('*') if p.is_file()}
ledger={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in files.items()}
archive=out/'review-proof.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
seen=set()
with tarfile.open(archive,'r:gz') as t:
 for m in t:
  assert m.isfile() and m.name in ledger and m.name not in seen;seen.add(m.name)
  h=hashlib.sha256();size=0
  with t.extractfile(m) as f:
   for block in iter(lambda:f.read(1024*1024),b''):h.update(block);size+=len(block)
  assert size==m.size==ledger[m.name]['bytes'] and h.hexdigest()==ledger[m.name]['sha256']
assert seen==set(ledger)
for name,p in files.items():assert sha(p)==ledger[name]['sha256'],name
(out/'manifest.json').write_text(json.dumps(dict(original_archive_sha256=whole.hexdigest(),original_archive_bytes=sum(p['bytes'] for p in parts),original_parts=parts,original_archive_members=summary['archive_members'],all_original_members_verified=True,review_archive_sha256=sha(archive),review_archive_bytes=archive.stat().st_size,review_members=ledger,all_review_members_verified=True,all_parts_concat_sha_verified=True),indent=2)+'\n')
(out/'independent-review.json').write_bytes((review/'independent-review.json').read_bytes())
(out/'original-member-manifest.json').write_bytes((root/'archive-manifest.json').read_bytes())
print(json.dumps(dict(parts=len(parts),original_bytes=sum(p['bytes'] for p in parts),review_members=len(ledger),review_bytes=archive.stat().st_size,review_sha256=sha(archive))))
